"""Reusable RGB/HSV classification for SortingEnv's agentview images.

MuJoCo segmentation supplies object regions; this module classifies colors,
not object detection. Robot observations and control are unchanged.
"""
from __future__ import annotations
import math
from pathlib import Path
import mujoco
import numpy as np
from PIL import Image, ImageDraw
from . import config as C
from .env import SortingEnv
METHODS = ("RGB", "HSV")

def rgb_to_hsv(rgb: np.ndarray) -> np.ndarray:
    """[0,1] RGB 배열을 [0,1) H, [0,1] S, [0,1] V로 변환한다."""
    x = np.asarray(rgb, dtype=np.float64)
    r, g, b = x[..., 0], x[..., 1], x[..., 2]
    maximum = np.max(x, axis=-1)
    minimum = np.min(x, axis=-1)
    delta = maximum - minimum

    hue = np.zeros_like(maximum)
    nz = delta > np.finfo(np.float64).eps
    red = nz & (maximum == r)
    green = nz & (maximum == g)
    blue = nz & (maximum == b)
    hue[red] = np.mod((g[red] - b[red]) / delta[red], 6.0)
    hue[green] = (b[green] - r[green]) / delta[green] + 2.0
    hue[blue] = (r[blue] - g[blue]) / delta[blue] + 4.0
    hue /= 6.0

    saturation = np.zeros_like(maximum)
    positive = maximum > np.finfo(np.float64).eps
    saturation[positive] = delta[positive] / maximum[positive]
    return np.stack([hue, saturation, maximum], axis=-1)


def _prototypes(names: list[str]) -> np.ndarray:
    return np.asarray([
        [float(v) for v in C.OBJECT_BY_NAME[name]["rgba"].split()[:3]]
        for name in names
    ], dtype=np.float64)


def classify_pixels(pixels_rgb: np.ndarray, prototypes_rgb: np.ndarray,
                    method: str) -> np.ndarray:
    """각 픽셀에 가장 가까운 기준색 index를 돌려준다."""
    if method == "RGB":
        distances = np.mean(
            (pixels_rgb[:, None, :] - prototypes_rgb[None, :, :]) ** 2,
            axis=2,
        )
    elif method == "HSV":
        pixels_hsv = rgb_to_hsv(pixels_rgb)
        prototypes_hsv = rgb_to_hsv(prototypes_rgb)
        hue_delta = np.abs(pixels_hsv[:, None, 0] - prototypes_hsv[None, :, 0])
        hue_delta = 2.0 * np.minimum(hue_delta, 1.0 - hue_delta)
        sat_delta = pixels_hsv[:, None, 1] - prototypes_hsv[None, :, 1]
        val_delta = pixels_hsv[:, None, 2] - prototypes_hsv[None, :, 2]
        # H의 최대 원형 거리는 0.5이므로 2배 해 [0,1]로 맞춘 뒤 세 채널을 동등 가중한다.
        distances = (hue_delta ** 2 + sat_delta ** 2 + val_delta ** 2) / 3.0
    else:
        raise ValueError(method)
    return np.argmin(distances, axis=1)


def erode_mask(mask: np.ndarray, iterations: int) -> np.ndarray:
    result = np.asarray(mask, dtype=bool)
    for _ in range(iterations):
        padded = np.pad(result, 1, mode="constant", constant_values=False)
        neighbours = [
            padded[dy:dy + result.shape[0], dx:dx + result.shape[1]]
            for dy in range(3) for dx in range(3)
        ]
        result = np.logical_and.reduce(neighbours)
    return result


def render_with_masks(env: SortingEnv, names: list[str]) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    # RGB 영상은 실제 분류 입력이고 segmentation은 물체 영역을 고르는 정답 정보다.
    # 따라서 이 함수의 점수는 물체 검출 성능이나 VLA 제어 성공률이 아니다.
    rgb = env.render("agentview")
    renderer = env._renderer(env.image_size, env.image_size)
    renderer.enable_segmentation_rendering()
    try:
        renderer.update_scene(env.data, camera="agentview")
        segmentation = renderer.render().copy()
    finally:
        renderer.disable_segmentation_rendering()

    geom_type = int(mujoco.mjtObj.mjOBJ_GEOM)
    masks = {}
    for name in names:
        geom_id = mujoco.mj_name2id(
            env.model, mujoco.mjtObj.mjOBJ_GEOM, f"{name}_geom"
        )
        masks[name] = ((segmentation[..., 0] == geom_id)
                       & (segmentation[..., 1] == geom_type))
    return rgb, masks


def score_scene(image: np.ndarray, masks: dict[str, np.ndarray], names: list[str],
                prototypes: np.ndarray, mask_erosion: int) -> tuple[list[dict], dict]:
    rows: list[dict] = []
    annotations: dict[str, dict[str, str]] = {method: {} for method in METHODS}
    for truth_index, name in enumerate(names):
        original_mask = masks[name]
        mask = erode_mask(original_mask, mask_erosion)
        if int(mask.sum()) < C.COLOR_EXPERIMENT_MIN_VISIBLE_PIXELS:
            mask = original_mask
        pixels = image[mask]
        if len(pixels) == 0:
            for method in METHODS:
                rows.append({
                    "method": method, "truth": name, "prediction": "not_visible",
                    "correct": 0, "pixel_accuracy": math.nan, "visible_pixels": 0,
                })
                annotations[method][name] = "not_visible"
            continue

        for method in METHODS:
            predicted_indices = classify_pixels(pixels, prototypes, method)
            counts = np.bincount(predicted_indices, minlength=len(names))
            prediction = names[int(np.argmax(counts))]
            rows.append({
                "method": method,
                "truth": name,
                "prediction": prediction,
                "correct": int(prediction == name),
                "pixel_accuracy": float(np.mean(predicted_indices == truth_index)),
                "visible_pixels": int(len(pixels)),
            })
            annotations[method][name] = prediction
    return rows, annotations


def save_annotated(image: np.ndarray, masks: dict[str, np.ndarray], predictions: dict[str, str],
                   path: Path, method: str) -> None:
    annotated_image(image, masks, predictions, method).save(path)


def annotated_image(image: np.ndarray, masks: dict[str, np.ndarray],
                    predictions: dict[str, str], method: str) -> Image.Image:
    canvas = Image.fromarray(np.uint8(np.clip(image * 255.0, 0, 255)))
    draw = ImageDraw.Draw(canvas)
    for name, mask in masks.items():
        yy, xx = np.where(mask)
        if len(xx) == 0:
            continue
        box = (int(xx.min()), int(yy.min()), int(xx.max()), int(yy.max()))
        correct = predictions.get(name) == name
        color = (30, 220, 80) if correct else (255, 60, 60)
        draw.rectangle(box, outline=color, width=2)
        draw.text((box[0], max(0, box[1] - 10)), predictions.get(name, "?"), fill=color)
    draw.text((5, 5), method, fill=(255, 255, 255), stroke_width=2, stroke_fill=(0, 0, 0))
    return canvas


class ColorRecognizer:
    """Classify known object regions in the current simulation state.

    Methods consume the same normalized RGB image. HSV conversion is internal.
    `truth` is a simulation identifier for evaluation, not a predicted identity.
    """

    def __init__(self, methods=METHODS, names=None):
        self.methods = tuple(methods)
        self.names = list(C.OBJECT_NAMES if names is None else names)
        if not self.methods or set(self.methods) - set(METHODS):
            raise ValueError("methods must contain RGB and/or HSV")
        if not self.names or len(set(self.names)) != len(self.names):
            raise ValueError("names must be nonempty and unique")
        if set(self.names) - set(C.OBJECT_NAMES):
            raise ValueError("unknown object name")
        self.prototypes = _prototypes(self.names)

    def recognize(self, image_rgb_u8, masks):
        """Return (rows, overlays) for uint8 RGB H×W×3 and boolean H×W masks.

        Each row contains method, truth, prediction, correct, pixel_accuracy,
        visible_pixels. Overlays is a dict of method -> PIL RGB image.
        """
        image = np.asarray(image_rgb_u8)
        if image.dtype != np.uint8 or image.ndim != 3 or image.shape[-1] != 3:
            raise ValueError("image must be uint8 RGB with shape (H,W,3)")
        for name in self.names:
            mask = np.asarray(masks[name])
            if mask.shape != image.shape[:2] or mask.dtype != bool:
                raise ValueError("masks must be boolean arrays matching image height/width")
        normalized = image.astype(np.float64) / 255.0
        rows, predictions = score_scene(normalized, masks, self.names, self.prototypes,
                                       C.COLOR_EXPERIMENT_MASK_EROSION)
        overlays = {method: annotated_image(normalized, masks, predictions[method], method)
                    for method in self.methods}
        return [row for row in rows if row["method"] in self.methods], overlays

    def observe(self, env):
        """Render and classify the current SortingEnv state without stepping it."""
        image, masks = render_with_masks(env, self.names)
        rows, overlays = self.recognize(image, masks)
        return image, rows, overlays

