r"""RGB 3채널과 HSV 3채널의 물체 색상 인식 성능을 짝지어 비교한다.

이 스크립트가 측정하는 것:
  - MuJoCo agentview 의 같은 RGB 픽셀을 두 방법에 모두 입력한다.
  - RGB: 정규화된 (R, G, B) 공간에서 기준색과 유클리드 거리 비교.
  - HSV: (H, S, V) 공간에서 비교. H는 원형 변수이므로 0/1 경계를 이어서 계산한다.
  - MuJoCo segmentation mask는 정답 물체 픽셀을 고르는 채점용으로만 사용한다.
  - 물체별 다수결 정확도와 픽셀 정확도, confusion matrix를 저장한다.
  - 같은 장면의 RGB/HSV 결과를 짝지어 장면 단위 bootstrap 95% CI를 계산한다.

주의: 이것은 색공간 자체의 효과를 분리한 색상 분류 실험이다. 물체 검출, 모양 인식,
VLM 성능까지 측정하는 실험은 아니다. 사전학습 VLM에 HSV 값을 RGB처럼 넣는 것은
입력 분포 이탈을 함께 만들므로 이 비교에서는 하지 않는다.

기본 실행(3 layout x 30 seeds x 10 objects):
  .\.venv\Scripts\python.exe -X utf8 scripts\color_space_recognition_experiment.py

빨강/초록/파랑 물체 3개만 제한:
  .\.venv\Scripts\python.exe -X utf8 scripts\color_space_recognition_experiment.py --objects rgb-primary

밝기/센서잡음 강건성 비교(디지털 교란이며 실제 조명 변화와 같다고 해석하면 안 됨):
  .\.venv\Scripts\python.exe -X utf8 scripts\color_space_recognition_experiment.py --brightness 0.7,1.0,1.3 --noise-std 0,8
"""

from __future__ import annotations

import _bootstrap
import argparse
import csv
import hashlib
import json
import math
import time
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image

from vlapipe import config as C
from vlapipe.env import SortingEnv
from vlapipe.color_recognition import (
    rgb_to_hsv, _prototypes, classify_pixels, erode_mask, render_with_masks,
    score_scene, save_annotated,
)


METHODS = ("RGB", "HSV")


def _csv_values(text: str, cast):
    values = [cast(x.strip()) for x in text.split(",") if x.strip()]
    if not values:
        raise argparse.ArgumentTypeError("쉼표로 구분한 값을 하나 이상 넣어 주세요.")
    return values


def _seed_values(text: str) -> list[int]:
    """'3', '3,7,11', '0:30', '0:30:2' 형식을 받는다."""
    if ":" not in text:
        return _csv_values(text, int)
    parts = [int(x.strip()) for x in text.split(":")]
    if len(parts) not in (2, 3):
        raise argparse.ArgumentTypeError("seed 범위는 start:stop 또는 start:stop:step 형식입니다.")
    values = list(range(*parts))
    if not values:
        raise argparse.ArgumentTypeError("seed 범위가 비어 있습니다.")
    return values


def _object_names(text: str) -> list[str]:
    if text == "all":
        return list(C.OBJECT_NAMES)
    if text == "rgb-primary":
        return list(C.COLOR_EXPERIMENT_PRIMARY_OBJECTS)
    names = _csv_values(text, str)
    unknown = sorted(set(names) - set(C.OBJECT_NAMES))
    if unknown:
        raise argparse.ArgumentTypeError(f"알 수 없는 물체: {unknown}")
    return names


def parse_args() -> argparse.Namespace:
    seed_stop = C.COLOR_EXPERIMENT_SEED_START + C.COLOR_EXPERIMENT_N_SEEDS
    ap = argparse.ArgumentParser(
        description="같은 MuJoCo 이미지에서 RGB 3채널과 HSV 3채널 색상 인식을 비교합니다."
    )
    ap.add_argument("--layouts", default=",".join(C.COLOR_EXPERIMENT_LAYOUTS),
                    help="쉼표 구분: tidy,messy,random,cluttered")
    ap.add_argument("--seeds", default=f"{C.COLOR_EXPERIMENT_SEED_START}:{seed_stop}",
                    help="예: 3 또는 3,7,11 또는 0:30")
    ap.add_argument("--objects", default="all",
                    help="all, rgb-primary, 또는 물체 이름의 쉼표 목록")
    ap.add_argument("--brightness",
                    default=",".join(str(x) for x in C.COLOR_EXPERIMENT_BRIGHTNESS),
                    help="동일 이미지에 적용할 밝기 배율 목록")
    ap.add_argument("--noise-std",
                    default=",".join(str(x) for x in C.COLOR_EXPERIMENT_NOISE_STD),
                    help="동일 이미지에 적용할 Gaussian 잡음 표준편차(0~255 단위)")
    ap.add_argument("--image-size", type=int, default=C.COLOR_EXPERIMENT_IMAGE_SIZE)
    ap.add_argument("--mask-erosion", type=int, default=C.COLOR_EXPERIMENT_MASK_EROSION,
                    help="경계 혼합 픽셀을 제외할 mask erosion 횟수")
    ap.add_argument("--bootstrap-samples", type=int,
                    default=C.COLOR_EXPERIMENT_BOOTSTRAP_SAMPLES)
    ap.add_argument("--bootstrap-seed", type=int,
                    default=C.COLOR_EXPERIMENT_RANDOM_SEED)
    ap.add_argument("--out", default=str(C.OUTPUT_DIR / "color_space_recognition"))
    args = ap.parse_args()

    args.layouts = _csv_values(args.layouts, str)
    invalid_layouts = sorted(set(args.layouts) - {"tidy", "messy", "random", "cluttered"})
    if invalid_layouts:
        ap.error(f"알 수 없는 layout: {invalid_layouts}")
    try:
        args.seeds = _seed_values(args.seeds)
        args.objects = _object_names(args.objects)
        args.brightness = _csv_values(args.brightness, float)
        args.noise_std = _csv_values(args.noise_std, float)
    except argparse.ArgumentTypeError as exc:
        ap.error(str(exc))
    if args.image_size < 64:
        ap.error("--image-size 는 64 이상이어야 합니다.")
    if args.mask_erosion < 0:
        ap.error("--mask-erosion 은 0 이상이어야 합니다.")
    if args.bootstrap_samples < 100:
        ap.error("--bootstrap-samples 는 100 이상이어야 합니다.")
    if any(x <= 0 for x in args.brightness):
        ap.error("밝기 배율은 0보다 커야 합니다.")
    if any(x < 0 for x in args.noise_std):
        ap.error("잡음 표준편차는 0 이상이어야 합니다.")
    # 같은 입력을 중복 실행해 표본 수가 부풀려지는 것을 막는다.
    args.layouts = list(dict.fromkeys(args.layouts))
    args.seeds = list(dict.fromkeys(args.seeds))
    args.objects = list(dict.fromkeys(args.objects))
    args.brightness = list(dict.fromkeys(args.brightness))
    args.noise_std = list(dict.fromkeys(args.noise_std))
    return args












def perturb_image(rgb_u8: np.ndarray, brightness: float, noise_std: float,
                  rng: np.random.Generator) -> np.ndarray:
    image = rgb_u8.astype(np.float64) / 255.0
    image *= brightness
    if noise_std > 0:
        image += rng.normal(0.0, noise_std / 255.0, image.shape)
    return np.clip(image, 0.0, 1.0)


def stable_rng_seed(*parts: object) -> int:
    raw = "|".join(map(str, parts)).encode("utf-8")
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], "little")




def bootstrap_ci(values: np.ndarray, samples: int,
                 rng: np.random.Generator) -> tuple[float, float]:
    values = np.asarray(values, dtype=np.float64)
    if len(values) == 0:
        return math.nan, math.nan
    if len(values) == 1:
        return float(values[0]), float(values[0])
    chunk = min(1000, samples)
    means = []
    remaining = samples
    while remaining:
        n = min(chunk, remaining)
        indices = rng.integers(0, len(values), size=(n, len(values)))
        means.append(values[indices].mean(axis=1))
        remaining -= n
    estimates = np.concatenate(means)
    low, high = np.quantile(estimates, [0.025, 0.975])
    return float(low), float(high)


def macro_f1(rows: list[dict], names: list[str], method: str) -> float:
    selected = [row for row in rows if row["method"] == method]
    scores = []
    for name in names:
        tp = sum(row["truth"] == name and row["prediction"] == name for row in selected)
        fp = sum(row["truth"] != name and row["prediction"] == name for row in selected)
        fn = sum(row["truth"] == name and row["prediction"] != name for row in selected)
        denominator = 2 * tp + fp + fn
        scores.append(0.0 if denominator == 0 else (2.0 * tp) / denominator)
    return float(np.mean(scores))


def exact_mcnemar_p(rgb_only_correct: int, hsv_only_correct: int) -> float:
    discordant = rgb_only_correct + hsv_only_correct
    if discordant == 0:
        return 1.0
    tail = min(rgb_only_correct, hsv_only_correct)
    probability = sum(math.comb(discordant, k) for k in range(tail + 1)) / (2 ** discordant)
    return float(min(1.0, 2.0 * probability))


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_confusion(path: Path, rows: list[dict], names: list[str], method: str) -> None:
    selected = [row for row in rows if row["method"] == method]
    prediction_names = names + (["not_visible"] if any(
        row["prediction"] == "not_visible" for row in selected) else [])
    matrix_rows = []
    for truth in names:
        counts = Counter(row["prediction"] for row in selected if row["truth"] == truth)
        matrix_rows.append({"truth": truth, **{name: counts[name] for name in prediction_names}})
    write_csv(path, matrix_rows, ["truth", *prediction_names])




def save_plot(path: Path, overall: dict[str, dict], comparison: dict) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    methods = list(METHODS)
    values = [overall[m]["object_accuracy"] for m in methods]
    lower = [values[i] - overall[m]["ci95"][0] for i, m in enumerate(methods)]
    upper = [overall[m]["ci95"][1] - values[i] for i, m in enumerate(methods)]
    fig, ax = plt.subplots(figsize=(6.4, 4.4))
    bars = ax.bar(methods, values, color=["#4c78a8", "#f58518"],
                  yerr=np.asarray([lower, upper]), capsize=7)
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("Object recognition accuracy")
    ax.set_title("Paired RGB vs HSV color-space experiment")
    ax.grid(axis="y", alpha=0.25)
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, value + 0.025,
                f"{value:.3f}", ha="center")
    delta = comparison["accuracy_difference_hsv_minus_rgb"]
    lo, hi = comparison["difference_ci95"]
    ax.text(0.5, 0.04, f"HSV - RGB = {delta:+.3f} (95% CI {lo:+.3f}, {hi:+.3f})",
            transform=ax.transAxes, ha="center")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def main() -> int:
    args = parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    prototypes = _prototypes(args.objects)
    started = time.time()
    rows: list[dict] = []
    sample_written: set[str] = set()

    print("RGB vs HSV 색상 인식 비교를 시작합니다.")
    print(f"  layouts={args.layouts}, seeds={len(args.seeds)}개, objects={args.objects}")
    print(f"  brightness={args.brightness}, noise_std={args.noise_std}")

    env = SortingEnv(layout=args.layouts[0], seed=args.seeds[0],
                     image_size=args.image_size, cameras=("agentview",))
    try:
        total_scenes = len(args.layouts) * len(args.seeds)
        scene_number = 0
        for layout in args.layouts:
            for seed in args.seeds:
                scene_number += 1
                env.reset(layout=layout, seed=seed)
                rgb_u8, masks = render_with_masks(env, args.objects)
                if scene_number == 1 or scene_number % 10 == 0 or scene_number == total_scenes:
                    print(f"  scene {scene_number}/{total_scenes}: {layout} seed={seed}")

                for brightness in args.brightness:
                    for noise_std in args.noise_std:
                        rng = np.random.default_rng(stable_rng_seed(
                            args.bootstrap_seed, layout, seed, brightness, noise_std
                        ))
                        image = perturb_image(rgb_u8, brightness, noise_std, rng)
                        scored, annotations = score_scene(
                            image, masks, args.objects, prototypes, args.mask_erosion
                        )
                        scene_key = f"{layout}|{seed}|{brightness:g}|{noise_std:g}"
                        for row in scored:
                            row.update({
                                "scene_key": scene_key,
                                "layout": layout,
                                "seed": seed,
                                "brightness": brightness,
                                "noise_std": noise_std,
                            })
                            rows.append(row)

                        if layout not in sample_written:
                            raw_path = out / f"sample_{layout}_input.png"
                            Image.fromarray(np.uint8(np.clip(image * 255.0, 0, 255))).save(raw_path)
                            for method in METHODS:
                                save_annotated(
                                    image, masks, annotations[method],
                                    out / f"sample_{layout}_{method}.png", method,
                                )
                            sample_written.add(layout)
    finally:
        env.close()

    fieldnames = [
        "scene_key", "layout", "seed", "brightness", "noise_std", "method",
        "truth", "prediction", "correct", "pixel_accuracy", "visible_pixels",
    ]
    write_csv(out / "per_object.csv", rows, fieldnames)
    for method in METHODS:
        write_confusion(out / f"confusion_{method}.csv", rows, args.objects, method)

    scene_keys = sorted({row["scene_key"] for row in rows})
    seeds = sorted({int(row["seed"]) for row in rows})

    # 같은 seed에서 나온 layout/교란/물체를 먼저 평균한다. 픽셀이나 물체 수를
    # 독립 표본 수로 잘못 세지 않고, 비교 실험의 반복 단위를 seed 하나로 둔다.
    seed_scores: dict[int, dict[str, float]] = {}
    for seed in seeds:
        seed_scores[seed] = {}
        for method in METHODS:
            values = [row["correct"] for row in rows
                      if row["seed"] == seed and row["method"] == method]
            seed_scores[seed][method] = float(np.mean(values))

    bootstrap_rng = np.random.default_rng(args.bootstrap_seed)
    overall: dict[str, dict] = {}
    summary_rows: list[dict] = []
    for method in METHODS:
        method_rows = [row for row in rows if row["method"] == method]
        scores = np.asarray([seed_scores[seed][method] for seed in seeds])
        ci = bootstrap_ci(scores, args.bootstrap_samples, bootstrap_rng)
        overall[method] = {
            "object_accuracy": float(np.mean([row["correct"] for row in method_rows])),
            "seed_mean_accuracy": float(scores.mean()),
            "ci95": list(ci),
            "macro_f1": macro_f1(rows, args.objects, method),
            "mean_pixel_accuracy": float(np.nanmean([
                row["pixel_accuracy"] for row in method_rows
            ])),
            "n_object_observations": len(method_rows),
            "n_images": len(scene_keys),
            "n_seed_replicates": len(seeds),
        }
        summary_rows.append({"scope": "overall", "group": "all", "method": method,
                             **overall[method]})

    for layout in args.layouts:
        for method in METHODS:
            selected = [row for row in rows
                        if row["layout"] == layout and row["method"] == method]
            layout_seeds = sorted({int(row["seed"]) for row in selected})
            scores = np.asarray([
                np.mean([row["correct"] for row in selected if row["seed"] == seed])
                for seed in layout_seeds
            ])
            ci = bootstrap_ci(scores, args.bootstrap_samples, bootstrap_rng)
            summary_rows.append({
                "scope": "layout", "group": layout, "method": method,
                "object_accuracy": float(np.mean([row["correct"] for row in selected])),
                "seed_mean_accuracy": float(scores.mean()),
                "ci95": json.dumps(list(ci)),
                "macro_f1": macro_f1(selected, args.objects, method),
                "mean_pixel_accuracy": float(np.nanmean([
                    row["pixel_accuracy"] for row in selected
                ])),
                "n_object_observations": len(selected),
                "n_images": len({row["scene_key"] for row in selected}),
                "n_seed_replicates": len(layout_seeds),
            })

    paired_differences = np.asarray([
        seed_scores[seed]["HSV"] - seed_scores[seed]["RGB"] for seed in seeds
    ])
    difference_ci = bootstrap_ci(paired_differences, args.bootstrap_samples, bootstrap_rng)
    row_index = {(row["scene_key"], row["truth"], row["method"]): row for row in rows}
    rgb_only = hsv_only = 0
    for key in scene_keys:
        for name in args.objects:
            rgb_correct = row_index[(key, name, "RGB")]["correct"]
            hsv_correct = row_index[(key, name, "HSV")]["correct"]
            rgb_only += int(rgb_correct and not hsv_correct)
            hsv_only += int(hsv_correct and not rgb_correct)
    comparison = {
        "accuracy_difference_hsv_minus_rgb": float(paired_differences.mean()),
        "difference_ci95": list(difference_ci),
        "rgb_only_correct": rgb_only,
        "hsv_only_correct": hsv_only,
        "mcnemar_exact_two_sided_p": exact_mcnemar_p(rgb_only, hsv_only),
        "primary_inference_unit": (
            "seed (layout, perturbation, and object observations are averaged within seed "
            "before paired bootstrap)"
        ),
        "mcnemar_note": (
            "exploratory object-pair statistic; primary conclusion should use the "
            "seed-level paired bootstrap CI"
        ),
    }

    summary_fields = [
        "scope", "group", "method", "object_accuracy", "seed_mean_accuracy", "ci95",
        "macro_f1", "mean_pixel_accuracy", "n_object_observations", "n_images",
        "n_seed_replicates",
    ]
    serializable_summary_rows = []
    for row in summary_rows:
        copied = dict(row)
        if isinstance(copied["ci95"], list):
            copied["ci95"] = json.dumps(copied["ci95"])
        serializable_summary_rows.append(copied)
    write_csv(out / "summary.csv", serializable_summary_rows, summary_fields)

    report = {
        "experiment": "paired RGB-vs-HSV color recognition",
        "interpretation": {
            "RGB": "normalized Euclidean distance in R,G,B",
            "HSV": "normalized Euclidean distance in H,S,V with circular H distance",
            "ground_truth": "MuJoCo geom segmentation masks used only for scoring/cropping",
            "controlled": "same layout, seed, camera, pixels, mask, prototypes, and perturbation",
            "not_measured": ["object detection", "shape recognition", "VLM accuracy", "robot control"],
        },
        "args": {
            "layouts": args.layouts, "seeds": args.seeds, "objects": args.objects,
            "brightness": args.brightness, "noise_std": args.noise_std,
            "image_size": args.image_size, "mask_erosion": args.mask_erosion,
            "bootstrap_samples": args.bootstrap_samples, "bootstrap_seed": args.bootstrap_seed,
        },
        "overall": overall,
        "comparison": comparison,
        "elapsed_seconds": round(time.time() - started, 3),
        "references": {
            "hsv_definition": "https://docs.opencv.org/4.x/de/d25/imgproc_color_conversions.html",
            "paired_bootstrap": "https://www.itl.nist.gov/div898/software/dataplot/refman1/auxillar/bootplot.htm",
        },
    }
    (out / "report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    save_plot(out / "comparison.png", overall, comparison)

    print("\n결과")
    for method in METHODS:
        result = overall[method]
        print(f"  {method}: accuracy={result['object_accuracy']:.4f}, "
              f"95% CI=[{result['ci95'][0]:.4f}, {result['ci95'][1]:.4f}], "
              f"macro-F1={result['macro_f1']:.4f}")
    print(f"  HSV-RGB={comparison['accuracy_difference_hsv_minus_rgb']:+.4f}, "
          f"95% CI=[{difference_ci[0]:+.4f}, {difference_ci[1]:+.4f}]")
    print(f"  McNemar exact p={comparison['mcnemar_exact_two_sided_p']:.6g}")
    print(f"  저장 위치: {out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
