"""Explicit model contracts for the four-condition dense-scene comparison.

No image-derived plan is replaced with simulator truth. A VLA checkpoint must
declare two cameras, state16 and action7, plus saved preprocessing statistics.
Both native LeRobot processors and the standalone PilotProcessor are supported.
"""
from __future__ import annotations

import gc
import json
from pathlib import Path

import numpy as np

from . import config as C


CAMERA_ALIASES = {
    "observation.images.camera1": "agentview_image",
    "observation.images.camera2": "robot0_eye_in_hand_image",
    "observation.images.agentview": "agentview_image",
    "observation.images.wrist": "robot0_eye_in_hand_image",
}


def checkpoint_contract(checkpoint):
    root = Path(checkpoint).expanduser().resolve(strict=True)
    cfg = json.loads((root / "config.json").read_text(encoding="utf-8"))
    inputs, outputs = cfg["input_features"], cfg["output_features"]
    cameras = {k: v for k, v in inputs.items() if k.startswith("observation.images.")}
    if inputs.get("observation.state", {}).get("shape") != [C.STATE_DIM]:
        raise ValueError(f"{root}: expected state{C.STATE_DIM}; prepare a zero-step schema-adapted base checkpoint first")
    if outputs.get("action", {}).get("shape") != [C.ACTION_DIM]:
        raise ValueError(f"{root}: expected action{C.ACTION_DIM}; refusing action truncation/padding")
    if set(inputs) != set(cameras) | {"observation.state"}:
        raise ValueError("Unsupported additional trained input features")
    if len(cameras) != len(C.CAMERA_NAMES) or {CAMERA_ALIASES.get(k) for k in cameras} != {f"{cam}_image" for cam in C.CAMERA_NAMES}:
        raise ValueError("Checkpoint must explicitly map the two recorded cameras")
    pilot = root / "vlapipe_contract.json"
    if not pilot.exists() and not list(root.glob("*preprocessor*.json")):
        raise ValueError("Missing saved normalization/tokenization processors; raw strings are not VLA token inputs")
    if pilot.exists():
        pcfg = json.loads(pilot.read_text(encoding="utf-8"))
        if (pcfg["state_dim"], pcfg["action_dim"]) != (C.STATE_DIM, C.ACTION_DIM):
            raise ValueError("Pilot preprocessing dimensions differ from simulator")
        for stem, size in (("state", C.STATE_DIM), ("action", C.ACTION_DIM)):
            for stat in ("mean", "std"):
                values = np.asarray(pcfg[f"{stem}_{stat}"])
                if values.shape != (size,) or not np.isfinite(values).all() or (stat == "std" and np.any(values <= 0)):
                    raise ValueError(f"Invalid saved {stem}_{stat}")
    return root, cfg, "pilot" if pilot.exists() else "lerobot"


class VLAPolicy:
    def __init__(self, checkpoint, device="auto", backbone=None):
        import torch
        from lerobot.policies.smolvla.configuration_smolvla import SmolVLAConfig
        from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
        self.root, self.saved, self.kind = checkpoint_contract(checkpoint)
        self.torch, self.device = torch, C.pick_device(device)
        cfg = SmolVLAConfig.from_pretrained(self.root)
        cfg.device = self.device
        if backbone:
            cfg.vlm_model_name = str(backbone)
            cfg.load_vlm_weights = False  # the checkpoint already contains backbone weights
        self.policy = SmolVLAPolicy.from_pretrained(self.root, config=cfg, strict=True).to(self.device).eval()
        if self.kind == "pilot":
            from .vla_io import PilotProcessor
            self.processor = PilotProcessor.load(str(self.root), self.device)
        else:
            from lerobot.policies.factory import make_pre_post_processors
            self.pre, self.post = make_pre_post_processors(
                cfg, pretrained_path=str(self.root),
                preprocessor_overrides={"device_processor": {"device": self.device}},
            )

    def reset(self, seed=None):
        if seed is not None:
            self.torch.manual_seed(seed)
        self.policy.reset()

    def select_action(self, obs, task):
        from PIL import Image
        state = np.concatenate([np.asarray(obs[k]).ravel() for k in C.STATE_KEYS]).astype(np.float32)
        if state.shape != (C.STATE_DIM,) or not np.isfinite(state).all():
            raise ValueError("Expected finite LIBERO state16")
        images, batch = {}, {"task": str(task), "observation.state": self.torch.from_numpy(state)}
        for key, feature in self.saved["input_features"].items():
            if key not in CAMERA_ALIASES:
                continue
            source = CAMERA_ALIASES[key]
            image = np.asarray(obs[source])
            if image.ndim != 3 or image.shape[-1] != 3 or image.dtype != np.uint8:
                raise ValueError(f"{source}: expected HWC uint8 RGB")
            h, w = feature["shape"][-2:]
            if image.shape[:2] != (h, w):
                image = np.asarray(Image.fromarray(image).resize((w, h)))
            images[source] = image
            batch[key] = self.torch.from_numpy(image.copy()).permute(2, 0, 1).float() / 255
        with self.torch.inference_mode():
            if self.kind == "pilot":
                action = self.processor.decode(self.policy.select_action(self.processor.batch(images, state, str(task))))
            else:
                action = self.post(self.policy.select_action(self.pre(batch)))
                action = action.squeeze(0).float().cpu().numpy()
        action = np.asarray(action, dtype=np.float32)
        if action.shape != (C.ACTION_DIM,) or not np.isfinite(action).all():
            raise ValueError(f"VLA returned invalid action: {action.shape}")
        action = np.clip(action, -1, 1)
        action[-1] = C.GRIPPER_CLOSE_CMD if action[-1] >= 0 else C.GRIPPER_OPEN_CMD
        return action


def planner_prompt(command, feedback=None):
    # Identical instructions and public sorting rule before and after tuning.
    # No positions, accessibility verdicts, missing-object lists or oracle plan.
    text = (
        "You plan actions for a parcel sorting robot from a top-down image. "
        "There are ten white cubes labelled 1 through 10. Cubes 1-5 belong in the RIGHT blue zone; "
        "cubes 6-10 belong in the LEFT green zone. Empty the olive center. "
        "Do not transport a cube already in its correct zone. "
        "Return ONLY a JSON array of ordered steps. Each step must contain action "
        "(transport, clear or push), object (object_1 through object_10), and target_zone "
        "(left_zone or right_zone). A push may include push_to [x,y] in table coordinates. "
        "Use a clear or push before transport if the grasp is obstructed. "
        f"User command: {command}"
    )
    if feedback:
        text += "\nPrevious execution feedback: " + json.dumps(feedback, ensure_ascii=False)
    return text


class QwenVLM:
    def __init__(self, model_id, adapter=None, device="auto", quantization="4bit", revision=None):
        import torch
        from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration
        self.torch, self.device = torch, C.pick_device(device)
        dtype = (torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16) if self.device.startswith("cuda") else torch.float32
        self.dtype = dtype
        kwargs = {"dtype": dtype, "device_map": self.device}
        if revision and not Path(model_id).exists():
            kwargs["revision"] = revision
        if quantization == "4bit":
            if not self.device.startswith("cuda"):
                raise ValueError("4-bit Qwen requires CUDA; use --quantization none on CPU")
            from transformers import BitsAndBytesConfig
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=dtype,
            )
        self.model = Qwen2_5_VLForConditionalGeneration.from_pretrained(model_id, **kwargs).eval()
        processor_kwargs = {"max_pixels": C.DENSE_BENCHMARK["planner_image_size"] ** 2}
        if revision and not Path(model_id).exists():
            processor_kwargs["revision"] = revision
        self.processor = AutoProcessor.from_pretrained(model_id, **processor_kwargs)
        if adapter:
            from peft import PeftModel
            self.model = PeftModel.from_pretrained(self.model, str(adapter)).eval()

    def generate(self, image, command, feedback=None, max_new_tokens=None):
        from PIL import Image
        if not isinstance(image, Image.Image):
            image = Image.fromarray(image)
        prompt = planner_prompt(command, feedback)
        messages = [{"role": "user", "content": [{"type": "image"}, {"type": "text", "text": prompt}]}]
        text = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.processor(text=[text], images=[image], return_tensors="pt").to(self.device)
        with self.torch.inference_mode():
            ids = self.model.generate(**inputs, max_new_tokens=max_new_tokens or C.DENSE_BENCHMARK["max_new_tokens"], do_sample=False)
        return self.processor.batch_decode(ids[:, inputs.input_ids.shape[1]:], skip_special_tokens=True)[0], prompt


def release_models():
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except ImportError:
        pass
