"""Explicit, saved input/output contract for locally trained SmolVLA pilots."""
import json
from pathlib import Path

import numpy as np

from . import config as C

CAMERA_KEYS = {"agentview_image": "observation.images.camera1",
               "robot0_eye_in_hand_image": "observation.images.camera2"}


class PilotProcessor:
    def __init__(self, contract: dict, tokenizer, device: str):
        import torch
        self.torch, self.contract, self.tokenizer, self.device = torch, contract, tokenizer, device
        self.state_mean = torch.tensor(contract["state_mean"], device=device)
        self.state_std = torch.tensor(contract["state_std"], device=device)
        self.action_mean = torch.tensor(contract["action_mean"], device=device)
        self.action_std = torch.tensor(contract["action_std"], device=device)

    @classmethod
    def load(cls, checkpoint: str, device: str):
        from transformers import AutoTokenizer
        root = Path(checkpoint)
        contract = json.loads((root / "vlapipe_contract.json").read_text(encoding="utf-8"))
        if (contract["state_dim"], contract["action_dim"]) != (C.STATE_DIM, C.ACTION_DIM):
            raise ValueError("Checkpoint does not match the LIBERO state/action schema")
        return cls(contract, AutoTokenizer.from_pretrained(root / "tokenizer", local_files_only=True), device)

    def batch(self, images: dict, state: np.ndarray, task: str) -> dict:
        torch = self.torch
        state = np.asarray(state, np.float32)
        if state.shape != (C.STATE_DIM,) or not np.isfinite(state).all():
            raise ValueError("Expected finite 16-dimensional state")
        batch = {"observation.state": (torch.from_numpy(state).to(self.device)[None] -
                                       self.state_mean) / self.state_std}
        for source, target in CAMERA_KEYS.items():
            img = images[source]
            if img.ndim != 3 or img.shape[-1] != 3 or img.dtype != np.uint8:
                raise ValueError(f"Expected HWC uint8 RGB for {source}")
            batch[target] = torch.from_numpy(img.copy()).permute(2, 0, 1)[None].to(self.device).float() / 255
        encoded = self.tokenizer(task.rstrip() + "\n", return_tensors="pt", padding="max_length",
                                 truncation=True, max_length=self.contract["language_length"])
        batch["observation.language.tokens"] = encoded["input_ids"].to(self.device)
        batch["observation.language.attention_mask"] = encoded["attention_mask"].to(self.device).bool()
        return batch

    def decode(self, action) -> np.ndarray:
        result = ((action.float() * self.action_std) + self.action_mean).squeeze(0).cpu().numpy()
        if result.shape != (C.ACTION_DIM,) or not np.isfinite(result).all():
            raise ValueError("Policy returned an invalid seven-dimensional action")
        result[:6] = np.clip(result[:6], -1, 1)
        result[6] = C.GRIPPER_CLOSE_CMD if result[6] >= 0 else C.GRIPPER_OPEN_CMD
        return result.astype(np.float32)
