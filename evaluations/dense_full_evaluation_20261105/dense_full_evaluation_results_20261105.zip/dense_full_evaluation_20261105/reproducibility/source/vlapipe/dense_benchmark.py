"""Dense scenes: tuning(before/after) x architecture(single/hierarchical).

Extends the experiment protocol in Final_project sections 13-15, reviewed at
semin126/VLA2026 a6b294e859629b0307b2bdff4063bd25e097b589.
Single = the original whole-table command sent directly to VLA (no VLM).
Hierarchical = Qwen image plan -> instruction -> the same phase's VLA.
Optional A/B/C/D are a separate hierarchy ablation, never architecture aliases.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import time
import uuid
from pathlib import Path

import numpy as np

from . import config as C, numbered, accessibility as acc
from .env import SortingEnv
from .planner import to_subtask
from .scene_suite import load_scene


def dump(path, value):
    path = Path(path)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def snapshot(env):
    pos, yaw = env.object_xy_yaw()
    return {"positions": {n: list(p) for n, p in pos.items()}, "yaws": yaw,
            "sizes": {o["name"]: list(o["full"]) for o in C.OBJECTS},
            "home_zones": {o["name"]: o["home_zone"] for o in C.OBJECTS},
            "zones": C.ZONES, "robot_base": C.ROBOT_BASE_XY,
            "reach_limits": [C.REACH_MIN, C.REACH_MAX],
            "unfinished": env.misplaced_objects(),
            "gripper_geometry": {"half_open": acc.GRIPPER_HALF_OPEN,
                                 "finger_radius": acc.FINGER_RADIUS, "clear_margin": acc.CLEAR_MARGIN}}


def supported(env, name):
    return abs(env.object_pos(name)[2] - C.TABLE_TOP_Z - C.half_size(C.OBJECT_BY_NAME[name])[2]) < C.DENSE_BENCHMARK["support_tolerance_m"]


def released(env):
    return float(np.min(env.data.qpos[env._finger_adr])) > C.DENSE_BENCHMARK["released_finger_qpos"]


def completed(env):
    return env.is_tidy() and released(env) and all(supported(env, n) for n in C.OBJECT_NAMES)


def parse_proposals(raw):
    """Strict JSON schema: reject rather than guess missing object/zone/action."""
    text = raw.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines[-1].strip() == "```":
            text = "\n".join(lines[1:-1])
    try:
        rows = json.loads(text)
    except (ValueError, TypeError):
        return [], [{"reason": "invalid_json", "raw": raw}]
    if not isinstance(rows, list):
        return [], [{"reason": "plan_is_not_array", "proposal": rows}]
    valid, errors = [], []
    for index, st in enumerate(rows):
        reason = proposal_error(st)
        if reason:
            errors.append({"index": index, "proposal": st, "reason": reason})
        else:
            valid.append(to_subtask(st["object"], st["target_zone"], len(valid) + 1,
                                    st["action"], push_to=st.get("push_to")))
    return valid, errors


def proposal_error(st):
    if not isinstance(st, dict):
        return "step_is_not_object"
    if st.get("object") not in C.OBJECT_BY_NAME:
        return "unknown_object"
    if st.get("action") not in ("transport", "clear", "push"):
        return "unknown_or_missing_action"
    if st.get("target_zone") not in ("left_zone", "right_zone"):
        return "unknown_or_missing_zone"
    if st["action"] == "transport" and st["target_zone"] != C.OBJECT_BY_NAME[st["object"]]["home_zone"]:
        return "wrong_sorting_destination"
    if "push_to" in st:
        try:
            x, y = st["push_to"]
            if not (np.isfinite([x, y]).all() and C.WORK_X[0] <= x <= C.WORK_X[1] and C.WORK_Y[0] <= y <= C.WORK_Y[1]):
                return "push_destination_out_of_bounds"
        except (ValueError, TypeError):
            return "invalid_push_destination"
    return None


def load_design(path):
    spec = importlib.util.spec_from_file_location("chosen_dense_design", Path(path).resolve(strict=True))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for name in ("assess_accessibility", "choose_next", "should_replan"):
        if not callable(getattr(module, name, None)):
            raise ValueError(f"Design must define {name}")
    return module


def step_success(env, st, start_pos, peak):
    name, action = st["object"], st["action"]
    moved = float(np.linalg.norm(env.object_pos(name)[:2] - start_pos[:2]))
    if action == "transport":
        lifted = peak > start_pos[2] + C.DENSE_BENCHMARK["lift_clearance_m"]
        return env.zone_of(name) == st["target_zone"] and supported(env, name) and released(env) and lifted
    if action == "clear":
        return moved >= C.DENSE_BENCHMARK["clear_displacement_m"] and supported(env, name) and released(env)
    if st.get("push_to") is not None:
        return moved >= C.DENSE_BENCHMARK["clear_displacement_m"] and supported(env, name) and float(np.linalg.norm(env.object_pos(name)[:2] - np.asarray(st["push_to"]))) < C.DENSE_BENCHMARK["push_tolerance_m"]
    return moved >= C.DENSE_BENCHMARK["clear_displacement_m"] and supported(env, name)


def run_trial(*, case, phase, architecture, out, policy_factory, planner_generate=None,
              seed=None, mode="A", design_file=None, total_steps=None, subtask_steps=None,
              max_attempts=None, max_plan_calls=None, command=None, diagnostic=False,
              video=False, planner_image_size=None, policy_image_size=None, model_record=None):
    s = C.DENSE_BENCHMARK
    seed = s["seed"] if seed is None else seed
    total_steps = s["total_steps"] if total_steps is None else total_steps
    subtask_steps = s["subtask_steps"] if subtask_steps is None else subtask_steps
    max_attempts = s["max_attempts"] if max_attempts is None else max_attempts
    max_plan_calls = s["max_plan_calls"] if max_plan_calls is None else max_plan_calls
    command = command or s["command"]
    if architecture not in ("single", "hierarchical") or phase not in ("before", "after"):
        raise ValueError("Invalid phase/architecture")
    if architecture == "single" and mode != "A":
        raise ValueError("B/C/D are hierarchy ablations; single VLA has no high-level selector")
    if architecture == "hierarchical" and planner_generate is None:
        raise ValueError("Hierarchical architecture requires a planner")
    if min(total_steps, subtask_steps, max_attempts, max_plan_calls) < 1:
        raise ValueError("Budgets must be positive")
    if mode not in tuple("ABCD"):
        raise ValueError("mode must be A/B/C/D")
    if mode != "A" and not design_file:
        raise ValueError("B/C/D require an explicit design file")
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    report = {"protocol": "dense_four_condition_v1", "case": case, "phase": phase,
              "architecture": architecture, "mode": mode, "seed": seed, "command": command,
              "diagnostic_only": diagnostic, "models": model_record,
              "vla_observation_source": "two_RGB_cameras_and_state16",
              "vlm_observation_source": "agentview_RGB_and_command_and_execution_feedback",
              "completion_and_metrics_source": "simulator_state_oracle",
              "accessibility_source": "simulator_state_oracle" if mode in "BD" else "checker_disabled",
              "budgets": {"total_steps": total_steps, "subtask_steps": subtask_steps,
                          "max_attempts": max_attempts, "max_plan_calls": max_plan_calls},
              "planning": [], "decisions": [], "history": [], "stop_reason": None,
              "fixture_note": "Three fixed examples; repeated seeds are not new independent geometries."}
    design = None
    env = None
    xml = C.PANDA_DIR / ("dense_benchmark_" + uuid.uuid4().hex + ".xml")
    policy, writer, steps, calls = None, None, 0, 0
    planner_seconds = inference_seconds = model_load_seconds = 0.0
    start = time.perf_counter()
    try:
        if design_file:
            source = Path(design_file).read_bytes()
            report["design"] = {"path": str(design_file), "sha256": hashlib.sha256(source).hexdigest()}
            (out / "design_used.py").write_bytes(source)
            design = load_design(design_file)
        numbered.activate()
        env = SortingEnv(scene_path=xml, image_size=policy_image_size or s["policy_image_size"])
        load_scene(env, case)
        report["initial_scene"] = snapshot(env)
        report["initial_accessibility"] = env.accessibility_report()
        # Round only the geometry hash; the complete physical state has its own hash.
        geometry = {"positions": {n: [round(float(v), 6) for v in p] for n, p in report["initial_scene"]["positions"].items()},
                    "yaws": {n: round(float(v), 6) for n, v in report["initial_scene"]["yaws"].items()},
                    "sizes": report["initial_scene"]["sizes"]}
        report["initial_geometry_sha256"] = digest(geometry)
        report["initial_state_sha256"] = hashlib.sha256(env.data.qpos.tobytes() + env.data.qvel.tobytes() + env.data.ctrl.tobytes()).hexdigest()
        np.savez_compressed(out / "initial_state.npz", qpos=env.data.qpos.copy(), qvel=env.data.qvel.copy(), ctrl=env.data.ctrl.copy())
        from PIL import Image
        Image.fromarray(env.render("agentview", s["planner_image_size"], s["planner_image_size"])).save(out / "before.png")
        if video:
            import imageio.v2 as imageio
            writer = imageio.get_writer(out / "rollout.mp4", fps=C.CONTROL_HZ / s["video_every"])
        attempts, queue, need_plan = {}, [], architecture == "hierarchical"
        stable_scene = 0
        with (out / "actions.jsonl").open("x", encoding="utf-8") as action_log:
            while steps < total_steps:
                if completed(env):
                    stable_scene += 1
                    if stable_scene >= s["stable_steps"]:
                        report["stop_reason"] = "scene_completed"
                        break
                else:
                    stable_scene = 0
                if architecture == "hierarchical":
                    if need_plan:
                        if calls >= max_plan_calls:
                            report["stop_reason"] = "planner_call_cap"; break
                        # Release VLA before Qwen inference, keeping 6-GB GPUs usable.
                        policy = None
                        from .dense_models import release_models
                        release_models()
                        calls += 1
                        feedback = [{k: h[k] for k in ("object", "action", "success", "failure", "timed_out")} for h in report["history"]]
                        began = time.perf_counter()
                        raw, prompt, load_seconds = planner_generate(env.render("agentview", planner_image_size or s["planner_image_size"], planner_image_size or s["planner_image_size"]), command, feedback)
                        elapsed = time.perf_counter() - began
                        planner_seconds += elapsed - load_seconds
                        model_load_seconds += load_seconds
                        queue, errors = parse_proposals(raw)
                        record = {"call": calls, "raw_response": raw, "prompt": prompt,
                                  "parsed_plan": queue, "errors": errors,
                                  "seconds_with_load": elapsed, "model_load_seconds": load_seconds}
                        report["planning"].append(record)
                        dump(out / f"plan_{calls}.json", record)
                        need_plan = False
                    state = snapshot(env)
                    state.update(attempts=dict(attempts), max_attempts=max_attempts)
                    queue = [st for st in queue if attempts.get(st["object"], 0) < max_attempts and
                             not (st["action"] == "transport" and env.zone_of(st["object"]) == st["target_zone"] and supported(env, st["object"]))]
                    if not queue:
                        feedback = {"success": False, "failure": "empty_or_exhausted_plan", "timed_out": False}
                        if mode in "CD" and design.should_replan(state, feedback, report["history"]) and any(attempts.get(n, 0) < max_attempts for n in state["unfinished"]):
                            need_plan = True; continue
                        report["stop_reason"] = "empty_or_exhausted_plan"; break
                    assessments = [design.assess_accessibility(state, st) for st in queue] if mode in "BD" else None
                    chosen = design.choose_next(state, queue, assessments, report["history"]) if mode in "BD" else queue[0]
                    report["decisions"].append({"proposals": queue.copy(), "assessments": assessments, "chosen": chosen})
                    if chosen is None:
                        report["stop_reason"] = "no_admissible_action"; break
                    if chosen not in queue or proposal_error(chosen):
                        raise ValueError("Design selected an invalid/non-proposed action; model errors are not repaired with oracle actions")
                    name = chosen["object"]
                    attempts[name] = attempts.get(name, 0) + 1
                    queue.remove(chosen)
                    task = chosen["instruction"]
                    limit = min(subtask_steps, total_steps - steps)
                else:
                    chosen, task = None, command
                    limit = total_steps - steps
                if policy is None:
                    began = time.perf_counter(); policy = policy_factory(env)
                    model_load_seconds += time.perf_counter() - began
                policy.reset(seed + steps)
                if diagnostic:
                    policy.set_subtask(chosen)
                start_pos = env.object_pos(chosen["object"]) if chosen else None
                peak = float(start_pos[2]) if chosen else None
                stable, n = 0, 0
                while n < limit:
                    began = time.perf_counter()
                    action = policy.select_action(env.get_obs(), task)
                    inference_seconds += time.perf_counter() - began
                    action = np.asarray(action, np.float32)
                    if action.shape != (C.ACTION_DIM,) or not np.isfinite(action).all():
                        raise ValueError("Invalid LIBERO action7")
                    obs, _, _, _ = env.step(action)
                    n += 1; steps += 1
                    action_log.write(json.dumps({"step": steps, "task": task, "action": action.tolist()}) + "\n")
                    if writer and steps % s["video_every"] == 0:
                        writer.append_data(env.render("frontview", C.RENDER_SIZE[1], C.RENDER_SIZE[0]))
                    success = completed(env) if chosen is None else step_success(env, chosen, start_pos, max(peak, float(env.object_pos(chosen["object"])[2])))
                    if chosen:
                        peak = max(peak, float(env.object_pos(chosen["object"])[2]))
                    stable = stable + 1 if success else 0
                    if stable >= s["stable_steps"]:
                        break
                    if diagnostic and policy.done:
                        break
                if chosen:
                    feedback = {"object": chosen["object"], "action": chosen["action"], "success": bool(stable >= s["stable_steps"] or (diagnostic and step_success(env, chosen, start_pos, peak))),
                                "failure": policy.failure if diagnostic else (None if stable >= s["stable_steps"] else "completion_not_observed"),
                                "timed_out": n == limit and stable < s["stable_steps"], "steps": n,
                                "peak_lift_m": peak - float(start_pos[2]), "attempt": attempts[chosen["object"]]}
                    report["history"].append(feedback)
                    if completed(env) and stable >= s["stable_steps"]:
                        report["stop_reason"] = "scene_completed"
                        break
                    if mode in "CD" and design.should_replan(snapshot(env), feedback, report["history"]):
                        need_plan = True
                else:
                    report["stop_reason"] = "scene_completed" if stable >= s["stable_steps"] else "total_step_budget"
                    break
                dump(out / "progress.json", {"steps": steps, "planning_calls": calls, "history": report["history"]})
            if report["stop_reason"] is None:
                report["stop_reason"] = "total_step_budget"
    except BaseException as exc:
        report["error"] = {"type": type(exc).__name__, "message": str(exc)}
        report["stop_reason"] = "error"
        raise
    finally:
        report["summary"] = {"scene_completed": bool(env and completed(env) and report["stop_reason"] == "scene_completed"), "total_steps": steps,
                             "sim_seconds": steps / C.CONTROL_HZ, "planner_calls": calls,
                             "planner_inference_seconds": planner_seconds, "vla_inference_seconds": inference_seconds,
                             "model_load_seconds": model_load_seconds, "wall_seconds": time.perf_counter() - start}
        if env:
            report["final_scene"] = snapshot(env)
            report["summary"]["final_misplaced"] = env.misplaced_objects()
            correct = sum(env.zone_of(n) == C.OBJECT_BY_NAME[n]["home_zone"] and supported(env, n) for n in C.OBJECT_NAMES)
            report["summary"]["object_hit_rate"] = correct / len(C.OBJECT_NAMES)
            try:
                from PIL import Image
                Image.fromarray(env.render("agentview", s["planner_image_size"], s["planner_image_size"])).save(out / "after.png")
                np.savez_compressed(out / "final_state.npz", qpos=env.data.qpos.copy(), qvel=env.data.qvel.copy(), ctrl=env.data.ctrl.copy())
            except Exception as exc:
                report["artifact_error"] = {"type": type(exc).__name__, "message": str(exc)}
            finally:
                env.close()
        if writer:
            try:
                writer.close()
            except Exception as exc:
                report["video_error"] = {"type": type(exc).__name__, "message": str(exc)}
        xml.unlink(missing_ok=True)
        dump(out / "report.json", report)
    return report
