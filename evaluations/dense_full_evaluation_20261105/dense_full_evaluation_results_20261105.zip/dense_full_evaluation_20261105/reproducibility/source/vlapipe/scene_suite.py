"""Load three fixed, ten-cube accessibility fixtures without changing defaults.

Coordinates and expected counts are scene data in scenes/accessibility10.
Accessibility labels describe the existing conservative, fixed-yaw checker;
they do not prove physical impossibility for every possible grasp or policy.
"""
from __future__ import annotations

import json
from pathlib import Path

from . import config as C, scene

SCENE_DIR = C.PROJECT_DIR / "scenes" / "accessibility10"


def manifest() -> dict:
    return json.loads((SCENE_DIR / "manifest.json").read_text(encoding="utf-8"))


def read_layout(name: str) -> dict:
    spec = manifest()
    if name not in spec["cases"]:
        raise ValueError(f"Unknown fixture {name!r}; choose {list(spec['cases'])}")
    if (C.ACTIVE_OBJECT_SET != "number" or len(C.OBJECT_NAMES) != spec["object_count"]
            or any(tuple(o["full"]) != tuple(spec["object_full_m"]) for o in C.OBJECTS)):
        raise ValueError("Activate the ten uniform numbered cubes BEFORE constructing SortingEnv.")
    layout = json.loads((SCENE_DIR / f"{name}.json").read_text(encoding="utf-8"))
    if set(layout) != set(C.OBJECT_NAMES):
        raise ValueError("Fixture object names do not match the active object set")
    return {n: tuple(p) for n, p in layout.items()}


def register_layouts() -> None:
    """Opt-in registration; fixture seeds repeat the same fixed geometry."""
    for name in manifest()["cases"]:
        scene.LAYOUTS[name] = lambda seed=0, name=name: read_layout(name)


def load_scene(env, name: str) -> dict:
    """Reset robot and objects, settle, and verify the requested initial state."""
    read_layout(name)
    if set(env._jnt_adr) != set(C.OBJECT_NAMES):
        raise ValueError("This environment was constructed with a different object set")
    register_layouts()
    # Use the environment's existing default in both the standalone and
    # upstream versions; upstream does not define architecture-pilot settings.
    env.reset(layout=name)
    report = env.accessibility_report()
    expected = manifest()["cases"][name]
    for key in ("n_accessible", "n_blocked", "n_unreachable"):
        if report[key] != expected[key]:
            raise RuntimeError(f"{name}: {key}={report[key]}, expected {expected[key]}")
    if len(env.misplaced_objects()) != manifest()["object_count"]:
        raise RuntimeError("Every object must initially require sorting")
    return report
