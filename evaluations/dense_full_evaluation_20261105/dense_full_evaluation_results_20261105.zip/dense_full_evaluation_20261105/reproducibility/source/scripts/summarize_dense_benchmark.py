"""Summarize every trial, including errors and exhausted budgets."""
import _bootstrap  # noqa: F401
import argparse
import csv
import json
from pathlib import Path


def planning_scores(report):
    if report.get("architecture") == "single" or not report.get("planning"):
        return {"plan_precision": None, "plan_recall": None, "plan_f1": None, "plan_format_valid": None}
    first = report["planning"][0]
    truth = {(n, report["initial_scene"]["home_zones"][n]) for n in report["initial_scene"]["unfinished"]}
    rows = list(first["parsed_plan"])
    rows += [e["proposal"] for e in first["errors"] if isinstance(e.get("proposal"), dict)]
    predicted = {(str(r.get("object")), str(r.get("target_zone"))) for r in rows if r.get("action") == "transport"}
    tp = len(predicted & truth)
    precision = tp / len(predicted) if predicted else 0.0
    recall = tp / len(truth) if truth else 0.0
    return {"plan_precision": precision, "plan_recall": recall,
            "plan_f1": 2 * precision * recall / (precision + recall) if precision + recall else 0.0,
            "plan_format_valid": not first["errors"]}


def summarize(root):
    root = Path(root)
    rows, geometries, states = [], {}, {}
    for path in sorted(root.glob("*/report.json")):
        r = json.loads(path.read_text(encoding="utf-8"))
        row = {k: r.get(k) for k in ("phase", "architecture", "case", "mode", "diagnostic_only", "seed", "stop_reason", "initial_geometry_sha256", "initial_state_sha256")}
        row.update(r.get("summary", {})); row.update(planning_scores(r))
        row["error"] = r.get("error")
        row["report"] = str(path.relative_to(root))
        rows.append(row)
        if r.get("initial_geometry_sha256"):
            geometries.setdefault(r["case"], set()).add(r["initial_geometry_sha256"])
            states.setdefault(r["case"], set()).add(r["initial_state_sha256"])
    fields = sorted(set().union(*(r.keys() for r in rows))) if rows else ["status"]
    with (root / "results.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()})
    summary = {"trials": rows, "same_initial_state_within_case": {case: len(hashes) == 1 for case, hashes in states.items()},
               "distinct_initial_geometries": len(set().union(*geometries.values())) if geometries else 0,
               "note": "Fixed three-scene diagnostics, not independent-scene statistics. Single VLA has no VLM-plan F1. Planning scores describe only initial transport object/destination sets, not manipulation order or actual task success."}
    (root / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Summary:", root / "results.csv", flush=True)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    summarize(parser.parse_args().root)
