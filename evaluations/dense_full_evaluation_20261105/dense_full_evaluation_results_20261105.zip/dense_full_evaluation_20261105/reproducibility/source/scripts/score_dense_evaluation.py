"""Score real dense-benchmark final states, without running or changing policies.

Common accuracy/F1 concerns the final physical sorting assignment. Plan F1 is
separate and only exists for hierarchical trials. Unplaced/unsupported objects
are abstentions, hence false negatives for their true left/right destination;
they are not a third valid destination whose abundance inflates macro F1.
"""
import _bootstrap  # noqa: F401
import argparse
import csv
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import uuid

import numpy as np

from vlapipe import config as C, numbered
from vlapipe.dense_benchmark import supported
from vlapipe.env import SortingEnv
from summarize_dense_benchmark import planning_scores


LABELS = ("left_zone", "right_zone")
CONDITION_KO = {
    "before_single": "튜닝 전 단일", "before_hierarchical": "튜닝 전 계층",
    "after_single": "기존 튜닝 후 단일", "after_hierarchical": "기존 튜닝 후 계층",
}
CASE_KO = {"all_accessible": "전체 접근 가능", "all_blocked": "전체 접근 불가", "mixed": "혼합"}


def assignment_scores(truth, predicted):
    if not truth or len(truth) != len(predicted) or any(v not in LABELS for v in truth):
        raise ValueError("Expected nonempty, matched left/right destination labels")
    confusion = {label: {column: 0 for column in (*LABELS, "unplaced")} for label in LABELS}
    per_class = {}
    for t, p in zip(truth, predicted):
        confusion[t][p if p in LABELS else "unplaced"] += 1
    for label in LABELS:
        tp = sum(t == label and p == label for t, p in zip(truth, predicted))
        fp = sum(t != label and p == label for t, p in zip(truth, predicted))
        fn = sum(t == label and p != label for t, p in zip(truth, predicted))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        per_class[label] = {"tp": tp, "fp": fp, "fn": fn, "precision": precision,
                            "recall": recall, "f1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0}
    tp, fp, fn = (sum(per_class[k][field] for k in LABELS) for field in ("tp", "fp", "fn"))
    return {"objects": len(truth), "correct": sum(t == p for t, p in zip(truth, predicted)),
            "accuracy": sum(t == p for t, p in zip(truth, predicted)) / len(truth),
            "macro_precision": sum(per_class[k]["precision"] for k in LABELS) / len(LABELS),
            "macro_recall": sum(per_class[k]["recall"] for k in LABELS) / len(LABELS),
            "macro_f1": sum(per_class[k]["f1"] for k in LABELS) / len(LABELS),
            "micro_precision": tp / (tp + fp) if tp + fp else 0.0,
            "micro_recall": tp / (tp + fn) if tp + fn else 0.0,
            "micro_f1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0,
            "unplaced": sum(p not in LABELS for p in predicted),
            "confusion": confusion, "per_class": per_class}


def write_csv(path, rows):
    fields = sorted(set().union(*(row.keys() for row in rows))) if rows else ["status"]
    with Path(path).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for k, v in row.items()})


def zone_distance(xy, target):
    zone = C.ZONES[target]
    return math.hypot(max(zone["x"][0] - xy[0], 0.0, xy[0] - zone["x"][1]),
                      max(zone["y"][0] - xy[1], 0.0, xy[1] - zone["y"][1]))


def score(root):
    root = Path(root)
    reports = sorted(root.glob("*/report.json"))
    expected = {(condition, case) for condition in C.DENSE_BENCHMARK["conditions"] for case in C.DENSE_BENCHMARK["cases"]}
    if not reports:
        raise ValueError("No completed report.json files")
    numbered.activate()
    xml = C.PANDA_DIR / ("score_dense_" + uuid.uuid4().hex + ".xml")
    env = SortingEnv(cameras=(), scene_path=xml)
    objects, trials, grouped = [], [], defaultdict(list)
    geometry_hashes, state_hashes, found = defaultdict(set), defaultdict(set), set()
    try:
        for report_path in reports:
            r = json.loads(report_path.read_text(encoding="utf-8"))
            if r.get("diagnostic_only"):
                raise ValueError("Diagnostic oracle/scripted results cannot be included in model evaluation")
            condition, case = r["phase"] + "_" + r["architecture"], r["case"]
            key = condition, case
            if key in found:
                raise ValueError(f"Duplicate evaluation condition: {key}")
            found.add(key)
            if not (report_path.parent / "final_state.npz").exists():
                raise ValueError(f"No final physical state: {report_path}")
            with np.load(report_path.parent / "final_state.npz") as saved:
                if saved["qpos"].shape != env.data.qpos.shape:
                    raise ValueError("Saved physical state does not match model schema")
                env.data.qpos[:] = saved["qpos"]
                env.data.qvel[:] = saved["qvel"]
            truth, predicted, distances = [], [], []
            for name in C.OBJECT_NAMES:
                target = C.OBJECT_BY_NAME[name]["home_zone"]
                position = env.object_pos(name)
                actual_zone = env.zone_of(name)
                on_table = bool(supported(env, name))
                pred = actual_zone if on_table and actual_zone in LABELS else None
                error = zone_distance(position[:2], target)
                row = {"condition": condition, "case": case, "object": name,
                       "true_zone": target, "predicted_zone": pred or "unplaced", "actual_xy_zone": actual_zone,
                       "supported_at_table_height": on_table, "correct": target == pred,
                       "x_m": float(position[0]), "y_m": float(position[1]), "z_m": float(position[2]),
                       "zone_boundary_distance_m": error}
                objects.append(row); truth.append(target); predicted.append(pred); distances.append(error)
            metrics = assignment_scores(truth, predicted)
            if not math.isclose(metrics["accuracy"], r["summary"]["object_hit_rate"]):
                raise RuntimeError(f"Reconstructed accuracy disagrees with actual execution report: {report_path}")
            plan = planning_scores(r)
            error_counts = defaultdict(int)
            for call in r["planning"]:
                for error in call["errors"]:
                    error_counts[error["reason"]] += 1
            trial = {"condition": condition, "case": case, "phase": r["phase"], "architecture": r["architecture"],
                     **metrics, **plan, **r["summary"], "stop_reason": r["stop_reason"], "error": r.get("error"),
                     "zone_mae_m": sum(distances) / len(distances), "zone_mse_m2": sum(d * d for d in distances) / len(distances),
                     "plan_error_counts": dict(error_counts), "report": str(report_path.relative_to(root)),
                     "initial_geometry_sha256": r["initial_geometry_sha256"], "initial_state_sha256": r["initial_state_sha256"]}
            trials.append(trial); grouped[condition].append((trial, truth, predicted, distances))
            geometry_hashes[case].add(r["initial_geometry_sha256"]); state_hashes[case].add(r["initial_state_sha256"])
    finally:
        env.close(); xml.unlink(missing_ok=True)
    conditions = []
    for condition in C.DENSE_BENCHMARK["conditions"]:
        group = grouped.get(condition, [])
        if not group:
            continue
        labels = [t for _, truth, _, _ in group for t in truth]
        preds = [p for _, _, predicted, _ in group for p in predicted]
        distances = [d for _, _, _, ds in group for d in ds]
        metrics = assignment_scores(labels, preds)
        row = {"condition": condition, "condition_ko": CONDITION_KO[condition], "scenes": len(group),
               "scenes_completed": sum(t["scene_completed"] for t, _, _, _ in group),
               "scene_success_rate": sum(t["scene_completed"] for t, _, _, _ in group) / len(group), **metrics,
               "error_trials": sum(bool(t["error"]) for t, _, _, _ in group),
               "zone_mae_m": sum(distances) / len(distances), "zone_mse_m2": sum(d * d for d in distances) / len(distances)}
        for field in ("wall_seconds", "model_load_seconds", "vla_inference_seconds", "planner_inference_seconds", "total_steps", "sim_seconds", "planner_calls"):
            row["mean_" + field] = sum(t[field] for t, _, _, _ in group) / len(group)
            row["total_" + field] = sum(t[field] for t, _, _, _ in group)
        for field in ("plan_precision", "plan_recall", "plan_f1", "plan_format_valid"):
            values = [t[field] for t, _, _, _ in group if t[field] is not None]
            row["mean_" + field] = sum(values) / len(values) if values else None
        row["stop_reason_counts"] = {reason: sum(t["stop_reason"] == reason for t, _, _, _ in group) for reason in {t["stop_reason"] for t, _, _, _ in group}}
        conditions.append(row)
    summary = {"complete": found == expected, "expected_trials": len(expected), "observed_trials": len(found),
               "missing_trials": sorted(expected - found), "conditions": conditions, "trials": trials,
               "initial_state_matches_across_conditions": {case: len(v) == 1 for case, v in state_hashes.items()},
               "distinct_geometries": len(set().union(*geometry_hashes.values())),
               "definitions": {
                   "accuracy": "Final supported objects in the correct left/right zone divided by all target objects.",
                   "macro_f1": "Mean of left/right destination F1, pooling all objects across that condition's scenes; unplaced/unsupported objects are FN, not a third correct class.",
                   "plan_f1": "Mean per-scene INITIAL transport object/destination set F1 for hierarchical trials only; invalid destinations and IDs remain errors, not repaired predictions.",
                   "time": "Wall time includes loading; model load is separately reported. Simulation time = control steps /20. Failures/early termination remain in all means.",
                   "distance": "Horizontal XY distance to correct zone boundary, not pose-prediction error.",
                   "scope": "Three fixed geometries, seed42; existing pilot checkpoints. No statistical significance or dense-scene-specific tuning claim."}}
    for filename, rows in (("condition_metrics.csv", conditions), ("trial_metrics.csv", trials), ("object_predictions.csv", objects)):
        write_csv(root / filename, rows)
    write_csv(root / "class_metrics.csv", [
        {"condition": row["condition"], "true_destination": label, **metrics}
        for row in conditions for label, metrics in row["per_class"].items()
    ])
    write_csv(root / "confusion_matrices.csv", [
        {"condition": row["condition"], "true_destination": truth, "final_destination": predicted, "objects": count}
        for row in conditions for truth, columns in row["confusion"].items() for predicted, count in columns.items()
    ])
    (root / "evaluation_metrics.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    result = score(args.root)
    print(json.dumps({"complete": result["complete"], "observed_trials": result["observed_trials"], "conditions": result["conditions"]}, ensure_ascii=False, indent=2))
