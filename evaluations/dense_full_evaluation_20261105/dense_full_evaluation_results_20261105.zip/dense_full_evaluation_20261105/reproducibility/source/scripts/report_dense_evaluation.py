"""Publish only a complete 12-trial real-model evaluation, with traceable metrics."""
import _bootstrap  # noqa: F401
import argparse
import html
import json
from pathlib import Path

from score_dense_evaluation import score, CONDITION_KO, CASE_KO


def figure(root, result):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter
    import numpy as np
    conditions = result["conditions"]
    names = ["Base\nsingle VLA", "Base\nQwen → VLA", "Tuned pilot\nsingle VLA", "Tuned pilot\nQwen → VLA"]
    colors = ["#64748b", "#93c5fd", "#334155", "#2563eb"]
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.8), layout="constrained")
    fig.suptitle("Real execution: 3 fixed scenes × 4 conditions (max 5,000 control steps)", fontsize=13, fontweight="bold")
    for ax, key, title, limit in [
        (axes[0], "accuracy", "Final sorting accuracy", 1),
        (axes[1], "macro_f1", "Final sorting macro F1", 1),
        (axes[2], "mean_plan_f1", "Initial VLM transport-plan F1", 1)]:
        values = [r[key] for r in conditions]
        ax.bar(np.arange(len(values)), [v if v is not None else 0 for v in values], color=colors, width=0.6)
        for i, value in enumerate(values):
            label = "N/A" if value is None else (f"{value:.1%}" if key == "accuracy" else f"{value:.4f}")
            ax.text(i, (value or 0) + 0.025, label, ha="center", fontsize=10)
        ax.set_xticks(np.arange(len(values)), names, fontsize=8)
        ax.set_ylim(0, limit + 0.1); ax.set_title(title, fontsize=11)
        if key == "accuracy":
            ax.yaxis.set_major_formatter(PercentFormatter(1))
        ax.spines[["top", "right"]].set_visible(False); ax.grid(axis="y", alpha=0.18); ax.set_axisbelow(True)
    fig.text(0.5, -0.025, "Tuned VLA was trained on color/shape scenes, not these number-cube scenes. Three fixed scenes do not establish statistical superiority.", ha="center", fontsize=8)
    fig.savefig(root / "metrics_overview.png", dpi=180, bbox_inches="tight")
    plt.close(fig)


def fmt(value, percent=False):
    if value is None:
        return "—"
    return f"{value * 100:.1f}%" if percent else f"{value:.4f}"


def report(root):
    root = Path(root)
    result = score(root)
    if not result["complete"] or not all(result["initial_state_matches_across_conditions"].values()):
        raise RuntimeError("The full 12 trials with matching initial states must finish before publishing")
    figure(root, result)
    lines = ["# 조밀한 숫자 큐브 3씬: 네 조건 실제 실행 결과", "",
        "실험 시작일: 2026-11-05. 각 씬에서 10개 물체 모두 처음에는 정리 대상이다. 최대 5000 제어 스텝, 계층 서브태스크당 최대 500스텝, seed 42, mode A로 실행했다. 빈 계획과 조기 실패도 분모에 포함했다.", "",
        "**모델 범위:** 튜닝 후는 현재 PC에 있던 Qwen LoRA·SmolVLA 파일럿 체크포인트다. SmolVLA는 색·모양 씬으로 학습되어 이번 숫자 큐브 씬과 입력 분포가 다르다. 이번 실행에서 새로 튜닝하지 않았다. 결과를 숫자 큐브에 맞춘 새 튜닝의 효과라고 해석하면 안 된다.", "",
        "## 최종 정리 결과 — 네 조건 공통 지표", "",
        "|조건|씬 완료|정답 구역·높이의 물체|정리 정확도|Macro Precision|Macro Recall|Macro F1|Micro F1|",
        "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in result["conditions"]:
        lines.append(f"|{r['condition_ko']}|{r['scenes_completed']}/{r['scenes']}|{r['correct']}/{r['objects']}|{fmt(r['accuracy'], True)}|{fmt(r['macro_precision'])}|{fmt(r['macro_recall'])}|{fmt(r['macro_f1'])}|{fmt(r['micro_f1'])}|")
    lines += ["", "정확도는 최종적으로 자기 목적 구역에 있고 테이블 높이에서 지지되는 물체 수 ÷ 전체 물체 수다. Macro F1은 왼쪽·오른쪽 목적지 F1의 평균이다. 가운데 남음·영역 밖·지지 높이 불일치는 목적지의 FN으로 반영한다. 미정리를 별도의 정답 클래스로 세지 않는다.", "",
        "## 최초 VLM 운반 계획", "",
        "|조건|평균 Precision|평균 Recall|평균 F1|전체 계획 검증 통과율|",
        "|---|---:|---:|---:|---:|"]
    for r in result["conditions"]:
        lines.append(f"|{r['condition_ko']}|{fmt(r['mean_plan_precision'])}|{fmt(r['mean_plan_recall'])}|{fmt(r['mean_plan_f1'])}|{fmt(r['mean_plan_format_valid'], True)}|")
    lines += ["", "단일 구조는 VLM을 호출하지 않으므로 계획 지표는 해당 없음이다. 계획 F1은 최초 계획의 transport 물체·목적지 집합을 채점한 씬별 F1의 평균이며, 실제 운반 F1이나 행동 순서 정확도가 아니다. 잘못된 ID·목적지와 깨진 형식을 자동으로 고치지 않았다. 검증 통과율은 JSON 문법뿐 아니라 실행 스키마·분류 규칙 검사까지 포함한다. 세 장면 모두 1~10번 전체가 정리 대상이므로, 같은 열 개 ID를 나열하는 고정 계획도 이 집합 F1에서는 1.0을 얻을 수 있다. 따라서 이것을 이미지 숫자 인식 정확도나 접근성 판단 능력으로 해석하면 안 된다.", "",
        "## 비용과 거리", "",
        "|조건|평균 제어 스텝|평균 실제 시간(초)|그중 모델 로드(초)|로드 제외 시간(초)|평균 시뮬레이션 시간(초)|구역 거리 MAE(m)|구역 거리 MSE(m²)|",
        "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in result["conditions"]:
        lines.append(f"|{r['condition_ko']}|{r['mean_total_steps']:.1f}|{r['mean_wall_seconds']:.2f}|{r['mean_model_load_seconds']:.2f}|{r['mean_wall_seconds']-r['mean_model_load_seconds']:.2f}|{r['mean_sim_seconds']:.2f}|{r['zone_mae_m']:.6f}|{r['zone_mse_m2']:.6f}|")
    lines += ["", "실제 시간에는 모델 로드·추론·시뮬레이션·렌더링이 포함된다. 초기 디스크/GPU 캐시 상태가 로드 시간에 영향을 준다. 시뮬레이션 시간은 제어 스텝/20이며 실제 로봇에서 측정한 작업 시간이 아니다. MAE/MSE는 최종 물체 중심에서 정답 구역 경계까지의 수평 거리이며 좌표 예측 오차가 아니다. 실패로 일찍 멈춰 시간이 짧아진 실행을 빠른 작업 성공으로 해석하면 안 된다.", "",
        "## 씬별 상세", "",
        "|씬|조건|정리 물체|정확도|정리 Macro F1|계획 F1|스텝|종료 이유|",
        "|---|---|---:|---:|---:|---:|---:|---|"]
    for r in result["trials"]:
        lines.append(f"|{CASE_KO[r['case']]}|{CONDITION_KO[r['condition']]}|{r['correct']}/{r['objects']}|{fmt(r['accuracy'], True)}|{fmt(r['macro_f1'])}|{fmt(r['plan_f1'])}|{r['total_steps']}|{r['stop_reason']}|")
    lines += ["", "## 실패 원인 기록", ""]
    for r in result["trials"]:
        if r["plan_error_counts"] or r["error"]:
            lines.append(f"- {CONDITION_KO[r['condition']]} / {CASE_KO[r['case']]}: 계획 오류 `{json.dumps(r['plan_error_counts'], ensure_ascii=False)}`; 실행 오류 `{r['error']}`.")
    lines += ["", "## 재현과 해석 범위", "",
        "12/12개 report와 최종 qpos를 읽어 물체별 위치·구역을 다시 계산했고, 실행 중 기록한 정리 정확도와 일치하는지 확인했다. 각 씬의 네 조건은 초기 물리 상태 hash가 같다.", "",
        "장면은 고정된 세 예시이고 반복 seed도 하나다. 물체 30개를 독립 씬 30개처럼 세거나, 이 결과로 구조의 통계적 우열을 결론 내리면 안 된다. 인식 정확도·접근성 판별 acc는 별도로 예측과 정답을 수집하지 않았으므로 측정했다고 표시하지 않는다.", "",
        "- [조건별 전체 지표](condition_metrics.csv)", "- [씬별 전체 지표](trial_metrics.csv)",
        "- [물체별 최종 위치와 정답](object_predictions.csv)", "- [계산 정의·혼동행렬·전체 수치](evaluation_metrics.json)",
        "- [목적지별 TP·FP·FN·Precision·Recall·F1](class_metrics.csv)", "- [최종 구역 혼동행렬](confusion_matrices.csv)",
        "- [실행 설정과 모델 경로](configuration.json)", "- [환경 버전](environment.json)", "",
        "각 trial 폴더의 report.json·plan_1.json·actions.jsonl·initial_state.npz·final_state.npz·before.png·after.png를 함께 보관했다."]
    markdown = "\n".join(lines) + "\n"
    (root / "RESULTS_KO.md").write_text(markdown, encoding="utf-8")
    # Self-contained numeric HTML; original before/after PNGs remain next to it.
    tables = []
    for title, headers, rows in [
        ("정리 결과", ["조건", "완료", "정확도", "정리 Macro F1", "계획 F1", "평균 시간(초)"],
         [[r["condition_ko"], f"{r['scenes_completed']}/{r['scenes']}", fmt(r["accuracy"], True), fmt(r["macro_f1"]), fmt(r["mean_plan_f1"]), f"{r['mean_wall_seconds']:.2f}"] for r in result["conditions"]]),
        ("씬별 결과", ["씬", "조건", "정확도", "정리 F1", "계획 F1", "제어 스텝", "종료 이유"],
         [[CASE_KO[r["case"]], CONDITION_KO[r["condition"]], fmt(r["accuracy"], True), fmt(r["macro_f1"]), fmt(r["plan_f1"]), str(r["total_steps"]), r["stop_reason"]] for r in result["trials"]])]:
        content = "<h2>" + html.escape(title) + "</h2><table><thead><tr>" + "".join("<th>"+html.escape(h)+"</th>" for h in headers) + "</tr></thead><tbody>"
        content += "".join("<tr>"+"".join("<td>"+html.escape(str(v))+"</td>" for v in row)+"</tr>" for row in rows)
        tables.append(content + "</tbody></table>")
    page = '<!doctype html><html lang="ko"><meta charset="utf-8"><title>조밀한 씬 4조건 실측 결과</title><style>body{font-family:system-ui,sans-serif;max-width:1200px;margin:40px auto;padding:0 20px;color:#172033;background:#f8fafc}table{border-collapse:collapse;width:100%;background:white;margin:20px 0 36px}th,td{padding:12px;border-bottom:1px solid #dce2ea;text-align:left}th{background:#e8eef7}p{line-height:1.7}a{color:#194c98}</style><h1>조밀한 숫자 큐브: 네 조건 실제 실행 결과</h1><p>2026-11-05 · 3씬 × 4조건 · 최대 5000 제어 스텝 · 기존 파일럿 튜닝 모델</p><p><b>튜닝 후 VLA는 색·모양 물체로 학습된 기존 모델이며, 이번 숫자 씬용 신규 학습 모델이 아닙니다.</b> 고정 3씬의 예비 측정으로 통계적 우열을 판단하지 않습니다.</p>'
    page += '<img src="metrics_overview.png" alt="네 조건의 정리 정확도, 정리 Macro F1, VLM 계획 F1" style="width:100%;height:auto">' + "".join(tables) + '<p>정리 F1은 최종 물체 목적지의 Macro F1입니다. 계획 F1은 계층 조건의 최초 운반 계획만 채점하며 단일 조건에는 해당하지 않습니다. 실패·미정리를 제외하지 않았습니다.</p><p><a href="RESULTS_KO.md">전체 설명</a> · <a href="condition_metrics.csv">조건별 CSV</a> · <a href="trial_metrics.csv">씬별 CSV</a> · <a href="object_predictions.csv">물체별 CSV</a></p></html>'
    (root / "RESULTS_KO.html").write_text(page, encoding="utf-8")
    print(root / "RESULTS_KO.md")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    report(parser.parse_args().root)
