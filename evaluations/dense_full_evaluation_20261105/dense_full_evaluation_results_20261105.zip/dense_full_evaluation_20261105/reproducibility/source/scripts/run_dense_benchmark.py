"""Run/preflight the four tuning x architecture conditions on the dense scenes."""
import _bootstrap  # noqa: F401
import argparse
import hashlib
import json
import time
from pathlib import Path

from vlapipe import config as C
from vlapipe.dense_benchmark import run_trial, dump, digest
from vlapipe.dense_models import checkpoint_contract, VLAPolicy, QwenVLM, release_models


def processor_identity(root):
    files = {}
    for path in Path(root).rglob("*"):
        rel = path.relative_to(root).as_posix()
        if path.is_file() and ("processor" in rel or "normalizer" in rel or rel.startswith("tokenizer/") or rel == "vlapipe_contract.json"):
            files[rel] = hashlib.sha256(path.read_bytes()).hexdigest()
    return digest(files)


def validate_config(cfg, selected):
    settings = C.DENSE_BENCHMARK
    if set(selected) - set(settings["conditions"]):
        raise ValueError("Unknown condition")
    for phase in {condition.split("_", 1)[0] for condition in selected}:
        model = cfg[phase]
        root, features, kind = checkpoint_contract(model["vla_checkpoint"])
        model["vla_checkpoint"] = str(root)
        if phase == "before":
            record = json.loads((root / "base_initialization.json").read_text(encoding="utf-8"))
            if record.get("optimizer_steps") != 0 or not record.get("all_source_tensors_exactly_unchanged"):
                raise ValueError("Before checkpoint is not a verified zero-step base")
        if phase == "after" and (root / "base_initialization.json").exists():
            raise ValueError("After checkpoint points to a zero-step base")
        if any(c.endswith("hierarchical") and c.startswith(phase) for c in selected):
            if not model.get("vlm_model"):
                raise ValueError("Hierarchical condition needs Qwen model ID/path")
            if phase == "before" and model.get("vlm_adapter"):
                raise ValueError("Before Qwen must not load a fine-tuned adapter")
            if phase == "after" and not model.get("vlm_adapter"):
                raise ValueError("After Qwen requires an explicit fine-tuned Qwen adapter")
            if model.get("vlm_adapter") and not (Path(model["vlm_adapter"]) / "adapter_config.json").exists():
                raise ValueError("Missing Qwen adapter_config.json")
            if model.get("vlm_adapter"):
                adapter_info = json.loads((Path(model["vlm_adapter"]) / "adapter_config.json").read_text(encoding="utf-8"))
                if "qwen" not in str(adapter_info.get("base_model_name_or_path", "")).lower():
                    raise ValueError("After VLM adapter is not identified as a Qwen adapter")
    if any(c.startswith("before") for c in selected) and any(c.startswith("after") for c in selected):
        if Path(cfg["before"]["vla_checkpoint"]).resolve() == Path(cfg["after"]["vla_checkpoint"]).resolve():
            raise ValueError("Before and after VLA paths must differ")
        if processor_identity(cfg["before"]["vla_checkpoint"]) != processor_identity(cfg["after"]["vla_checkpoint"]):
            raise ValueError("Before/after saved processors differ; use prepare_dense_base_vla.py with the after checkpoint as reference")
        if cfg["before"].get("vlm_model") != cfg["after"].get("vlm_model") or cfg["before"].get("vlm_revision") != cfg["after"].get("vlm_revision"):
            raise ValueError("Before/after must use the same Qwen base model and revision")
    return cfg


class DiagnosticPolicy:
    def __init__(self, env):
        from vlapipe.policy import ScriptedSortingPolicy
        self.policy = ScriptedSortingPolicy(env)
    def reset(self, seed=None):
        pass
    def set_subtask(self, st):
        self.policy.set_subtask(st)
    def select_action(self, obs, task):
        return self.policy.select_action()
    @property
    def done(self):
        return self.policy.done
    @property
    def failure(self):
        return self.policy.failure


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, help="Four-condition model-path JSON")
    parser.add_argument("--out", type=Path)
    parser.add_argument("--conditions", default=",".join(C.DENSE_BENCHMARK["conditions"]))
    parser.add_argument("--cases", default=",".join(C.DENSE_BENCHMARK["cases"]))
    parser.add_argument("--seed", type=int, default=C.DENSE_BENCHMARK["seed"])
    parser.add_argument("--mode", choices=list("ABCD"), default="A")
    parser.add_argument("--design-file", type=Path)
    parser.add_argument("--total-steps", type=int, default=C.DENSE_BENCHMARK["total_steps"])
    parser.add_argument("--subtask-steps", type=int, default=C.DENSE_BENCHMARK["subtask_steps"])
    parser.add_argument("--max-plan-calls", type=int, default=C.DENSE_BENCHMARK["max_plan_calls"])
    parser.add_argument("--max-new-tokens", type=int, default=C.DENSE_BENCHMARK["max_new_tokens"])
    parser.add_argument("--max-attempts", type=int, default=C.DENSE_BENCHMARK["max_attempts"])
    parser.add_argument("--preflight", action="store_true", help="No model download/load or simulation")
    parser.add_argument("--diagnostic", action="store_true", help="Oracle/scripted hierarchy wiring check, NOT model performance")
    parser.add_argument("--video", action="store_true")
    args = parser.parse_args()
    conditions = [s.strip() for s in args.conditions.split(",") if s.strip()]
    cases = [s.strip() for s in args.cases.split(",") if s.strip()]
    if not cases or set(cases) - set(C.DENSE_BENCHMARK["cases"]):
        parser.error("Choose configured dense cases")
    if not conditions or len(set(conditions)) != len(conditions):
        parser.error("Choose non-duplicate conditions")
    if min(args.total_steps, args.subtask_steps, args.max_plan_calls, args.max_attempts, args.max_new_tokens) < 1:
        parser.error("All budgets and token caps must be positive")
    if args.mode != "A" and not args.design_file:
        parser.error("B/C/D require --design-file")
    if args.mode != "A" and not args.diagnostic and any(c.endswith("_single") for c in conditions):
        parser.error("B/C/D are separate hierarchy ablations; select only *_hierarchical conditions")
    if args.diagnostic:
        conditions, cfg = ["before_hierarchical"], {}
    else:
        if not args.config:
            parser.error("--config is required for real model conditions")
        cfg = validate_config(json.loads(args.config.read_text(encoding="utf-8")), conditions)
    if args.preflight:
        print(json.dumps({"status": "passed", "conditions": conditions, "cases": cases, "models": cfg}, ensure_ascii=False, indent=2))
        return
    if not args.out:
        parser.error("--out is required; choose a fresh directory")
    args.out.mkdir(parents=True, exist_ok=False)
    dump(args.out / "configuration.json", {"arguments": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()}, "models": cfg, "defaults": C.DENSE_BENCHMARK})
    try:
        import torch
    except ImportError:
        if not args.diagnostic:
            raise
        torch = None
    import importlib.metadata
    import platform
    dump(args.out / "environment.json", {"python": platform.python_version(),
         "torch": torch.__version__ if torch else None, "cuda": bool(torch and torch.cuda.is_available()),
         "gpu": torch.cuda.get_device_name(0) if torch and torch.cuda.is_available() else None,
         "packages": {name: importlib.metadata.version(name) for name in ("mujoco", "numpy")}})
    if torch:
        torch.set_num_threads(C.DENSE_BENCHMARK["cpu_threads"])
    pair_hashes = {}
    errors = []
    for case in cases:
        for condition in conditions:
            phase, architecture = condition.split("_", 1)
            model = cfg.get(phase, {})
            def policy_factory(env):
                if args.diagnostic:
                    return DiagnosticPolicy(env)
                return VLAPolicy(model["vla_checkpoint"], cfg.get("policy_device", "auto"), model.get("vla_backbone"))
            def generate(image, command, feedback):
                if args.diagnostic:
                    from vlapipe import config as config
                    rows = [{"action": "transport", "object": n, "target_zone": config.OBJECT_BY_NAME[n]["home_zone"]} for n in config.OBJECT_NAMES]
                    return json.dumps(rows), "DIAGNOSTIC simulator-known object IDs and destinations", 0.0
                began = time.perf_counter()
                planner = QwenVLM(model["vlm_model"], model.get("vlm_adapter"), cfg.get("planner_device", "auto"), cfg.get("quantization", "4bit"), model.get("vlm_revision"))
                load_seconds = time.perf_counter() - began
                try:
                    raw, prompt = planner.generate(image, command, feedback, args.max_new_tokens)
                    return raw, prompt, load_seconds
                finally:
                    del planner
                    release_models()
            try:
                report = run_trial(case=case, phase=phase, architecture=architecture,
                    out=args.out / f"{condition}_{case}_{args.mode}", policy_factory=policy_factory,
                    planner_generate=generate if architecture == "hierarchical" else None,
                    seed=args.seed, mode=args.mode if architecture == "hierarchical" else "A", design_file=args.design_file if architecture == "hierarchical" else None,
                    total_steps=args.total_steps, subtask_steps=args.subtask_steps,
                    max_attempts=args.max_attempts, max_plan_calls=args.max_plan_calls,
                    diagnostic=args.diagnostic, video=args.video, model_record=model)
                expected = pair_hashes.setdefault(case, report["initial_state_sha256"])
                if expected != report["initial_state_sha256"]:
                    raise RuntimeError(f"Initial physical states differ across conditions: {case}")
                print(condition, case, report["summary"], flush=True)
            except Exception as exc:
                errors.append({"condition": condition, "case": case, "error": str(exc)})
                dump(args.out / "errors.json", errors)
                print("FAILED", condition, case, str(exc), flush=True)
            finally:
                release_models()
    from summarize_dense_benchmark import summarize
    summarize(args.out)
    if errors:
        raise SystemExit("Some trials failed. Reports and errors.json preserve those failures.")


if __name__ == "__main__":
    main()
