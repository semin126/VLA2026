# 숫자 큐브 10개 — 접근성 비교용 장면 3개

참고: [Final_project.ipynb 13~15절](https://github.com/semin126/VLA2026/blob/main/vla_pipeline/notebooks/Final_project.ipynb).
색·크기가 같은 숫자 큐브 10개를 사용한다. 1~5번은 오른쪽, 6~10번은 왼쪽 구역으로 정리한다.

|장면 이름|초기 접근 가능|초기 접근 불가|배치|
|---|---:|---:|---|
|`all_accessible`|10|0|두 열을 충분히 벌림. 모든 물체의 손가락 통로가 비어 있음|
|`all_blocked`|0|10|두 열을 붙임. 각 물체의 짝이 손가락 통로를 막음|
|`mixed`|5|5|짝수 물체의 파지 방향을 45도 회전. 짝수를 먼저 치우면 홀수의 통로가 열림|

세 장면 모두 물체가 로봇 도달 범위 안에 있고, 정리 대상은 10개다. 로봇·테이블·카메라·물체 수·크기·분류 규칙·액션7·state16·학습 카메라 2대는 기존 설정을 사용한다. 좌표와 자세는 각 JSON에 저장되어 있다. 고정 예시이므로 seed를 바꾸어도 새 장면이 되지 않는다.

## ‘접근 불가’의 정확한 뜻

기존 `vlapipe.accessibility.is_accessible` 기준을 그대로 쓴다. 정해진 파지 자세에서 손가락이 내려갈 자리에 다른 물체가 있는지를 보수적으로 판정한다. 카메라에 안 보인다는 뜻이 아니며, 모든 가능한 그리퍼 회전·밀기·재배치를 시도해도 절대 못 집는다는 뜻도 아니다.

실제로 `all_blocked`에서 스크립트 정책을 실행하면 옆 물체가 밀리면서 일부를 운반할 수 있었다. 이 장면의 0/10은 **초기 접근성 라벨**이다. 실제 운반 성공률 0%라는 의미로 보고하면 안 된다. 어떤 파지 자세를 허용할지는 이후 학생의 연구 설계에서 정해야 한다.

혼합 장면에서 처음 접근 가능한 물체는 **2·4·6·8·10번**, 막힌 물체는 **1·3·5·7·9번**이다. 짝 관계는 (1,6), (7,2), (3,8), (9,4), (5,10)이다. ‘짝수를 치우면 홀수가 열린다’는 가상 기하 검사이며, 실제 정책의 열 번 연속 정리 성공을 뜻하지 않는다.

## 파일과 설치

배포 ZIP은 **기존 `vla_pipeline` 폴더 안**에 푼다. `vlapipe/config.py` 등 기존 파일을 교체하지 않는다. 다음 새 파일을 사용한다.

- `scenes/accessibility10/*.json`: 배치와 장면 명세.
- `vlapipe/scene_suite.py`: 장면 등록·로딩·초기 라벨 검증.
- `scripts/make_accessibility_scenes.py`: 세 장면 생성·렌더링·안정성 검사.
- `scripts/run_scene_research_lab.py`: GitHub의 연구 실행기에 장면을 연결하는 어댑터.
- `outputs/accessibility_scenes_final_20261105/`: 검증 당시 이미지·XML·상태·기록.

Windows에서는 프로젝트 폴더에서 다음을 실행한다. 출력 폴더는 매번 새로 지정한다.

```powershell
$env:PYTHONUTF8='1'
.\.venv\Scripts\python.exe scripts\make_accessibility_scenes.py --out outputs\my_three_scenes
```

결과 폴더의 `overview.png`로 세 장면을 비교한다. 각 장면 폴더에 `agentview.png`, `frontview.png`, `layout.json`, `scene.xml`, `initial_state.npz`, `report.json`이 생긴다. frontview는 미리보기이며 학습용 카메라 목록을 늘리지 않는다.

XML은 프로젝트의 기존 Panda 메시와 숫자 텍스처를 참조한다. 이미지 파일만 따로 옮겨 보는 것은 가능하지만, XML만 다른 폴더로 옮기면 상대 에셋 경로가 깨진다. 다른 PC에서는 ZIP을 프로젝트 안에 풀고 위 생성 명령을 다시 실행하는 방법을 권한다.

## Python에서 장면 불러오기

```python
from vlapipe import numbered
from vlapipe.env import SortingEnv
from vlapipe.scene_suite import load_scene

numbered.activate()  # 기본 숫자 큐브 10개. env 생성 전에 실행
env = SortingEnv()
try:
    report = load_scene(env, "mixed")  # all_accessible / all_blocked / mixed
    print(report)
    image = env.render("agentview")
finally:
    env.close()
```

`load_scene`은 로봇과 모든 물체를 초기화하고 안정화한다. 다른 물체 세트나 크기가 활성화된 상태에서는 오류를 내므로, 기존 색 물체 환경에 숫자 좌표만 조용히 적용하는 실수를 막는다. 기존 tidy/messy/random/cluttered 기본값은 수정하지 않는다.

## Final_project 노트북에 연결

먼저 ZIP의 새 파일들이 노트북에서 실제 실행하는 원격 `PROJECT` 아래에 있어야 한다. Windows에만 파일을 복사하면 Colab에 전달되지 않는다.

노트북의 환경 설정·설치·기본 검사를 완료한 뒤 다음 셀로 장면을 확인한다. 기존 `script`, `stage`, `sync` 함수를 사용하므로 격리된 Python에서 실행된다.

```python
SCENE_PREVIEW = stage("three_scenes")
script("make_accessibility_scenes.py", "--out", SCENE_PREVIEW)
from IPython.display import Image, display
display(Image(filename=str(SCENE_PREVIEW / "overview.png")))
sync()
```

14절에서 이 장면들을 사용하려면 `CASES`를 `['all_accessible', 'all_blocked', 'mixed']`로 바꾸고, 실행 스크립트를 `run_scene_research_lab.py`, 물체 수를 `--count 10`으로 지정한다. 나머지 모델·모드·관측·행동 예산은 비교군 사이에 동일하게 유지한다. 어댑터는 장면 설정만 교체하고 학생의 접근성 판단·선택·재계획 함수는 구현하지 않는다.

```python
CASES = ["all_accessible", "all_blocked", "mixed"]
MODES = ["A"]  # B/C/D는 학생 설계 구현 후 사용
TRIAL_ROOT = stage("three_scene_trials")
TRIAL_ROOT.mkdir()
for case in CASES:
    script("run_scene_research_lab.py", "--mode", "A", "--case", case,
           "--seed", 0, "--count", 10,
           "--planner", "oracle_transport", "--policy", "scripted",
           "--total-budget", 1200, "--max-steps", 400, "--max-attempts", 2,
           "--out", TRIAL_ROOT / f"{case}_A")
```

위 예시는 원래 노트북의 연결 검사 예산을 유지한다. 물체 10개를 전부 정리하기에 충분한 예산인지는 별도로 정하고 고정해야 한다. 이 세 장면만으로 통계적 우열을 결론 내리지 않는다. 독립 반복 실험에는 추가 배치가 필요하다.

## 실제 검증 기록 — 2026-11-05

- 물리 안정화 후 접근 가능/막힘/도달 불가: **10/0/0, 0/10/0, 5/5/0**.
- 추가 안정화 후 라벨 유지. 물체끼리 침투한 접촉 0개. 세 장면 모두 정리 대상 10개.
- 전부 접근 가능 장면: 초기 상태를 매번 복원하여 각 물체를 하나씩 운반, **10개 모두 목표 구역 도착**, 정책 오류 없음.
- 혼합 장면: 초기 상태를 매번 복원하여 접근 가능한 5개를 하나씩 운반, **5개 모두 목표 구역 도착**, 정책 오류 없음.
- 전부 막힌 장면: 개별 검사에서 4개가 목표 구역까지 이동했지만 그 4개에도 정책의 정체 오류가 기록됨. 나머지 6개는 파지 실패. 시도 과정에서 물체 배치가 변하므로 초기 라벨과 실행 결과를 구분해야 함.
- 위 개별 운반 검사는 매번 초기화한 검사다. 열 개를 연속 정리한 실험이나 학습된 VLA 성능이 아니다.
- 내보낸 XML을 MuJoCo가 직접 로드했으며, 저장 qpos를 복원한 지오메트리 위치·방향은 원 환경과 일치했다. Panda의 COM 추적 조명 때문에 재렌더 픽셀은 약간 다를 수 있다. 수치는 `export_checks.json`에 기록했다.
- 코드 추가 후 `smoke_test.py` **5/5** 통과. 기존 `run_pipeline.py --layout messy --seed 3`은 **5/6**, 최종 정리 완료 True.
- GitHub에서 읽은 연구 실행기 소스로 어댑터의 세 장면 로딩을 각각 1스텝 검사했다. 로컬 숫자 모듈의 구형 함수 서명만 count=10 호환 래퍼로 연결했다. **Colab 원격 실행·학습 모델 비교·B/C/D 실험은 미실행**.

모든 결과는 `outputs/`에 저장했으며 연구 원본 `data/`는 수정하지 않았다.
