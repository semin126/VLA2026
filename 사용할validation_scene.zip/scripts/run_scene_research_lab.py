"""Adapter for Final_project section 14; requires the linked research_lab module.

Pass normal run_research_lab.py arguments through this adapter, with --case
all_accessible/all_blocked/mixed and --count 10. Only scene setup is replaced;
student decisions, model behavior and action budgets are preserved.
"""
import _bootstrap  # noqa: F401
import sys

from vlapipe.scene_suite import load_scene, manifest


def main():
    try:
        from vlapipe import research_lab
    except ImportError as exc:
        raise SystemExit("Use this adapter in the linked GitHub version with vlapipe/research_lab.py; local standalone distribution lacks that module.") from exc
    import run_research_lab as runner
    names = manifest()["cases"]
    if "--case" not in sys.argv or sys.argv[sys.argv.index("--case") + 1] not in names:
        raise SystemExit(f"Specify --case from {list(names)} and --count 10")
    selected = sys.argv[sys.argv.index("--case") + 1]
    if "--count" not in sys.argv or sys.argv[sys.argv.index("--count") + 1] != str(manifest()["object_count"]):
        raise SystemExit("These fixtures require --count 10")
    original_setup = research_lab.setup_case
    original_run = runner.run_trial

    def setup(env, case, seed):
        if case in names:
            load_scene(env, selected)
        else:
            original_setup(env, case, seed)

    research_lab.setup_case = setup
    def run_trial(**kwargs):
        kwargs["case"] = selected
        report = original_run(**kwargs)
        # Preserve ordinary report fields, but identify fixed-layout repeats.
        import json
        from pathlib import Path
        report["fixture_note"] = "Fixed ten-cube fixture. Seeds repeat geometry; these are three examples, not independent repeated scenes."
        (Path(kwargs["out"]) / "report.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return report

    runner.run_trial = run_trial
    # The upstream argparse choices predate these opt-in fixtures. Pass its
    # accepted placeholder through the parser, then replace it before execution.
    sys.argv[sys.argv.index("--case") + 1] = "open"
    try:
        runner.main()
    finally:
        research_lab.setup_case = original_setup
        runner.run_trial = original_run


if __name__ == "__main__":
    main()
