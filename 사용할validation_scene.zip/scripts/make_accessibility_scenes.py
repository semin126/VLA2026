"""Render and audit the three fixed ten-object scenes. No model download required."""
import _bootstrap  # noqa: F401
import argparse
import hashlib
import inspect
import json
import os
from datetime import datetime
from pathlib import Path
import uuid
import xml.etree.ElementTree as ET

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from vlapipe import config as C, numbered, scene
from vlapipe.env import SortingEnv
from vlapipe.scene_suite import SCENE_DIR, load_scene, manifest, read_layout, register_layouts


def export_xml(name, path):
    """Expand Panda include and resolve asset paths relative to this export."""
    root = ET.fromstring(scene.build_scene_xml(read_layout(name)))
    include = root.find("include")
    root.remove(include)
    panda = ET.parse(C.PANDA_PATCHED_XML).getroot()
    for child in reversed(list(panda)):
        root.insert(0, child)
    compiler = root.find("compiler")
    compiler.set("meshdir", os.path.relpath(C.PANDA_DIR / "assets", path.parent).replace("\\", "/"))
    for texture in root.findall(".//texture[@file]"):
        texture.set("file", os.path.relpath(texture.attrib["file"], path.parent).replace("\\", "/"))
    ET.indent(root)
    path.write_text(ET.tostring(root, encoding="unicode"), encoding="utf-8")
    # A saved file is useful only if MuJoCo can actually load it.
    return mujoco.MjModel.from_xml_path(C.mujoco_path(path))


def audit(env, name):
    report = load_scene(env, name)
    initial = env.data.qpos.copy()
    pos, yaw = env.object_xy_yaw()
    expected = manifest()["cases"][name]
    # The mixed scene must contain removable blockers, rather than a deadlock.
    if expected.get("unlock_after_removing_accessible"):
        from vlapipe import accessibility as acc
        remaining = {n: p for n, p in pos.items() if not env.is_accessible(n)[0]}
        if not all(acc.is_accessible(n, remaining, yaw)[0] for n in remaining):
            raise RuntimeError("Removing accessible cubes did not unlock the remaining cubes")
    # Repeat settling: test whether labels depend on a transient initial pose.
    env._sim_step(inspect.signature(env.reset).parameters["settle_steps"].default)
    stable = env.accessibility_report()
    for key in ("n_accessible", "n_blocked", "n_unreachable"):
        if report[key] != stable[key]:
            raise RuntimeError(f"Unstable accessibility labels: {name}")
    if not np.all(np.isfinite(env.data.qpos)):
        raise RuntimeError("Non-finite simulation state")
    # Every body must remain supported at its intended tabletop height.
    support_error = max(abs(env.object_pos(n)[2] - C.TABLE_TOP_Z - C.half_size(C.OBJECT_BY_NAME[n])[2])
                        for n in C.OBJECT_NAMES)
    # Check inter-object contacts for penetration. Table contact is expected.
    object_geoms = {mujoco.mj_name2id(env.model, mujoco.mjtObj.mjOBJ_GEOM, f"{n}_geom")
                    for n in C.OBJECT_NAMES}
    penetrations = [float(c.dist) for c in env.data.contact
                    if c.geom1 in object_geoms and c.geom2 in object_geoms and c.dist < 0]
    if penetrations:
        raise RuntimeError(f"Overlapping objects: {name}, {penetrations}")
    records = {n: {"position_m": env.object_pos(n).tolist(), "yaw_rad": env.object_yaw(n),
                   "accessible": env.is_accessible(n)[0], "reason": env.is_accessible(n)[1],
                   "blockers": env.blocking_objects(n)} for n in C.OBJECT_NAMES}
    geometry = {n: [*pos[n], yaw[n]] for n in C.OBJECT_NAMES}
    digest = hashlib.sha256(json.dumps(geometry, sort_keys=True).encode()).hexdigest()
    return {**report, "objects": records, "misplaced_count": len(env.misplaced_objects()),
            "geometry_sha256": digest, "support_height_error_max_m": float(support_error),
            "extra_settle_max_qpos_change": float(np.max(np.abs(env.data.qpos - initial))),
            "object_overlap_contacts": len(penetrations),
            "scope": "conservative fixed-yaw geometry checker; no transport-success claim"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=C.OUTPUT_DIR / ("accessibility_scenes_" + datetime.now().strftime("%Y%m%d_%H%M%S")))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    # activate() works with both this standalone distribution and linked main.
    numbered.activate()
    register_layouts()
    scene_xml = C.PANDA_DIR / ("scene_suite_" + uuid.uuid4().hex + ".xml")
    image_size = getattr(C, "NUMBER_IMAGE_SIZE", max(C.RENDER_SIZE))
    env = SortingEnv(scene_path=scene_xml, image_size=image_size)
    reports, tiles = {}, []
    try:
        for name, expected in manifest()["cases"].items():
            folder = args.out / name
            folder.mkdir()
            reports[name] = audit(env, name)
            (folder / "layout.json").write_bytes((SCENE_DIR / f"{name}.json").read_bytes())
            model = export_xml(name, folder / "scene.xml")
            if model.nq != env.model.nq:
                raise RuntimeError("Export changed state dimensions")
            np.savez_compressed(folder / "initial_state.npz", qpos=env.data.qpos.copy(),
                                qvel=env.data.qvel.copy(), ctrl=env.data.ctrl.copy())
            for camera in ("agentview", "frontview"):
                Image.fromarray(env.render(camera, image_size, image_size)).save(folder / f"{camera}.png")
            # Presentation contact sheet. Raw images above contain no labels.
            tile = Image.open(folder / "agentview.png").convert("RGB")
            draw = ImageDraw.Draw(tile)
            font = ImageFont.load_default(size=tile.width // 28)
            draw.rectangle((0, 0, tile.width, tile.height // 10), fill="white")
            draw.text((tile.width // 50, tile.height // 40), f"{name}: {reports[name]['n_accessible']}/10 accessible", fill="black", font=font)
            tiles.append(tile)
            (folder / "report.json").write_text(json.dumps(reports[name], ensure_ascii=False, indent=2), encoding="utf-8")
            print(name, {k: reports[name][k] for k in ("n_accessible", "n_blocked", "n_unreachable", "misplaced_count")})
        overview = Image.new("RGB", (sum(t.width for t in tiles), tiles[0].height), "white")
        x = 0
        for tile in tiles:
            overview.paste(tile, (x, 0)); x += tile.width
        overview.save(args.out / "overview.png")
        (args.out / "report.json").write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding="utf-8")
    finally:
        env.close()
        scene_xml.unlink(missing_ok=True)
    print(args.out)


if __name__ == "__main__":
    main()
